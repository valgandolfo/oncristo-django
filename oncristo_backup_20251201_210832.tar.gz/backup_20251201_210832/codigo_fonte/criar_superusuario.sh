#!/bin/bash

# Script para criar ou resetar superusuário no servidor Digital Ocean

echo "🔐 Criando/Resetando Superusuário..."
echo ""

# Ir para o diretório do projeto
cd /home/oncristo

# Ativar ambiente virtual
source venv/bin/activate

# Configurar ambiente de produção
export DJANGO_ENV=production

# Executar script Python para criar/atualizar superusuário
python manage.py shell << 'EOF'
from django.contrib.auth.models import User

# ⚠️ IMPORTANTE: O sistema usa EMAIL para login!
email = "admin@oncristo.com.br"  # ⚠️ Este será usado para login!
username = "admin"  # Pode ser qualquer coisa
password = "Admin123!"  # ⚠️ ALTERE ESTA SENHA!

# Verificar se já existe (por email ou username)
user = None
if User.objects.filter(email=email).exists():
    user = User.objects.get(email=email)
    print(f"✅ Usuário encontrado por email: {user.username}")
elif User.objects.filter(username=username).exists():
    user = User.objects.get(username=username)
    print(f"✅ Usuário encontrado por username: {user.username}")

if user:
    # Atualizar usuário existente
    user.set_password(password)
    user.email = email  # Garantir que o email está correto
    user.is_superuser = True
    user.is_staff = True
    user.save()
    print(f"✅ Usuário {user.username} atualizado!")
else:
    # Criar novo superusuário
    user = User.objects.create_superuser(
        username=username, 
        email=email, 
        password=password
    )
    print(f"✅ Superusuário {username} criado!")

print(f"\n📝 Credenciais para login:")
print(f"   📧 Email: {user.email}")
print(f"   🔑 Senha: {password}")
print(f"\n🌐 Teste em:")
print(f"   https://oncristo.com.br/admin/")
print(f"   https://oncristo.com.br/login/")
print(f"   https://oncristo.com.br/app_igreja/admin-area/")
EOF

echo ""
echo "✅ Concluído!"
echo ""
echo "🔄 Reiniciando Gunicorn..."
sudo systemctl restart gunicorn_oncristo
echo "✅ Gunicorn reiniciado!"
echo ""
echo "🌐 Teste o login nas URLs acima!"

