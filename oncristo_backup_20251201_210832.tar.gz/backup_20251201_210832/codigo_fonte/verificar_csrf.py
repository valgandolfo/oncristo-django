#!/usr/bin/env python
"""Script para verificar configuração CSRF"""
import os
import sys
import django

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'pro_igreja.settings')
django.setup()

from django.conf import settings

print("=" * 60)
print("🔍 VERIFICAÇÃO DE CONFIGURAÇÃO CSRF")
print("=" * 60)
print()
print(f"CSRF_TRUSTED_ORIGINS: {settings.CSRF_TRUSTED_ORIGINS}")
print()
print(f"ALLOWED_HOSTS: {settings.ALLOWED_HOSTS}")
print()
print("✅ Configuração carregada!")

