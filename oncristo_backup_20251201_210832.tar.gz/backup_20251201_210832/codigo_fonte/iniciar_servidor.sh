#!/bin/bash

# 🚀 SCRIPT PARA INICIAR APENAS O SERVIDOR DJANGO
# Use quando o ambiente já estiver configurado

echo "🌐 INICIANDO SERVIDOR DJANGO"
echo "============================"

# Cores para output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Verifica se está no diretório correto
if [ ! -f "manage.py" ]; then
    echo -e "${RED}❌ Você não está no diretório do projeto Django!${NC}"
    exit 1
fi

# Verifica se o ambiente virtual existe
if [ ! -d "venv" ]; then
    echo -e "${YELLOW}⚠️  Ambiente virtual não encontrado!${NC}"
    echo "Execute: ./iniciar_projeto.sh"
    exit 1
fi

# Ativa o ambiente virtual
echo -e "${BLUE}ℹ️  Ativando ambiente virtual...${NC}"
source venv/bin/activate

# Verifica se Django está instalado
if ! python -c "import django" 2>/dev/null; then
    echo -e "${YELLOW}⚠️  Django não encontrado!${NC}"
    echo "Execute: ./iniciar_projeto.sh"
    exit 1
fi

echo -e "${GREEN}✅ Ambiente virtual ativado!${NC}"
echo ""

# Mostra informações do servidor
echo -e "${PURPLE}🎉 SERVIDOR DJANGO INICIADO!${NC}"
echo ""
echo -e "${BLUE}📋 INFORMAÇÕES:${NC}"
echo "   🌐 URL: http://127.0.0.1:8000"
echo "   🔧 Debug: HABILITADO"
echo "   📊 Logs: VISÍVEIS NO TERMINAL"
echo "   🛑 Para parar: Ctrl+C"
echo ""
echo -e "${BLUE}🔗 URLs DISPONÍVEIS:${NC}"
echo "   🏠 Home: http://127.0.0.1:8000/"
echo "   🔐 Login: http://127.0.0.1:8000/login/"
echo "   📝 Registro: http://127.0.0.1:8000/register/"
echo "   ⚙️  Admin: http://127.0.0.1:8000/app_igreja/admin-area/"
echo "   🗄️  Django Admin: http://127.0.0.1:8000/admin/"
echo ""

# Detecta IP local da rede
IP_LOCAL=$(hostname -I | awk '{print $1}')
echo -e "${BLUE}📱 IP da rede local: ${IP_LOCAL}${NC}"
echo -e "${BLUE}📱 Acesse do celular: http://${IP_LOCAL}:8000${NC}"
echo ""

# Inicia o servidor com debug habilitado (0.0.0.0 permite acesso de outras máquinas na rede)
echo -e "${GREEN}🚀 Iniciando servidor...${NC}"
python manage.py runserver 0.0.0.0:8000 --verbosity=2
