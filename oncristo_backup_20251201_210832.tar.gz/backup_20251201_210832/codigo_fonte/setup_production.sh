#!/bin/bash
# Script de Setup Inicial para Produção no Digital Ocean
# Execute este script UMA VEZ no servidor

set -e

echo "🔧 Configurando servidor para produção..."

# Cores
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

# 1. Atualizar sistema
echo -e "${BLUE}1. Atualizando sistema...${NC}"
sudo apt update && sudo apt upgrade -y

# 2. Instalar dependências
echo -e "${BLUE}2. Instalando dependências...${NC}"
sudo apt install -y \
    python3 \
    python3-pip \
    python3-venv \
    python3-dev \
    postgresql-client \
    libpq-dev \
    nginx \
    git \
    build-essential \
    certbot \
    python3-certbot-nginx

# 3. Criar usuário django (se não existir)
if ! id "django" &>/dev/null; then
    echo -e "${BLUE}3. Criando usuário django...${NC}"
    sudo adduser --disabled-password --gecos "" django
    sudo usermod -aG sudo django
else
    echo -e "${YELLOW}⚠️  Usuário django já existe.${NC}"
fi

# 4. Configurar firewall
echo -e "${BLUE}4. Configurando firewall...${NC}"
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw --force enable

# 5. Criar diretórios
echo -e "${BLUE}5. Criando diretórios...${NC}"
sudo mkdir -p /home/django/oncristo
sudo chown django:django /home/django/oncristo

echo ""
echo -e "${GREEN}✅ Setup inicial concluído!${NC}"
echo ""
echo -e "${BLUE}📋 Próximos passos:${NC}"
echo "  1. Copiar projeto para /home/django/oncristo"
echo "  2. Criar arquivo .env_production"
echo "  3. Configurar ambiente virtual"
echo "  4. Executar migrações"
echo "  5. Configurar Gunicorn"
echo "  6. Configurar Nginx"
echo "  7. Configurar SSL"

