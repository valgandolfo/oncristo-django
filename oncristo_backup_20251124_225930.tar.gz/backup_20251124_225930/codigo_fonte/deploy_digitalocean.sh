#!/bin/bash

# 🚀 SCRIPT DE DEPLOY PARA DIGITALOCEAN
# Migração do PA para zap.oncristo.com.br

echo "🌐 DEPLOY FLASK PARA DIGITALOCEAN"
echo "=================================="

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

print_status() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Verificar se está no diretório correto
if [ ! -f "app.py" ]; then
    print_error "Você não está no diretório do projeto Flask!"
    exit 1
fi

print_status "Verificando estrutura do projeto..."

# 1. VERIFICAR ARQUIVOS ESSENCIAIS
print_info "1. Verificando arquivos essenciais..."

required_files=("app.py" "wsgi.py" "requirements.txt" ".env")
for file in "${required_files[@]}"; do
    if [ -f "$file" ]; then
        print_status "$file encontrado"
    else
        print_error "$file não encontrado!"
        exit 1
    fi
done

# 2. CRIAR ARQUIVO DE CONFIGURAÇÃO PARA PRODUÇÃO
print_info "2. Criando configuração para produção..."

cat > .env.production << EOF
# Configurações para produção no DigitalOcean
SECRET_KEY=production-secret-key-change-this
DEBUG=false

# API WhatsApp (manter as mesmas chaves)
WHAPI_KEY=zH945tTAfUZ26vKhYH0VHYMf3BSoPHIu
CHANNEL_ID=GRNLTR-64VV2

# Banco de dados MySQL no DO
DATABASE_URL=mysql://user:password@localhost/chatbotpa_db

# Servidor de produção
HOST=0.0.0.0
PORT=5000
EOF

print_status "Arquivo .env.production criado!"

# 3. CRIAR ARQUIVO DE CONFIGURAÇÃO NGINX
print_info "3. Criando configuração Nginx..."

cat > nginx_config.conf << EOF
server {
    listen 80;
    server_name zap.oncristo.com.br;
    
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    location /static {
        alias /home/ubuntu/chatbotpa/static;
        expires 30d;
    }
}
EOF

print_status "Configuração Nginx criada!"

# 4. CRIAR ARQUIVO SYSTEMD SERVICE
print_info "4. Criando serviço systemd..."

cat > chatbotpa.service << EOF
[Unit]
Description=ChatbotPA Flask Application
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/chatbotpa
Environment="PATH=/home/ubuntu/chatbotpa/venv/bin"
ExecStart=/home/ubuntu/chatbotpa/venv/bin/gunicorn --workers 3 --bind 127.0.0.1:5000 wsgi:application
Restart=always

[Install]
WantedBy=multi-user.target
EOF

print_status "Serviço systemd criado!"

# 5. CRIAR SCRIPT DE INSTALAÇÃO NO SERVIDOR
print_info "5. Criando script de instalação no servidor..."

cat > install_on_server.sh << 'EOF'
#!/bin/bash

# Script para instalar no servidor DigitalOcean
echo "🚀 INSTALANDO CHATBOTPA NO DIGITALOCEAN"

# Atualizar sistema
sudo apt update
sudo apt upgrade -y

# Instalar dependências
sudo apt install python3 python3-pip python3-venv nginx mysql-server mysql-client -y

# Criar usuário para a aplicação
sudo useradd -m -s /bin/bash chatbotpa

# Criar diretório da aplicação
sudo mkdir -p /home/ubuntu/chatbotpa
sudo chown ubuntu:ubuntu /home/ubuntu/chatbotpa

# Configurar MySQL
sudo mysql_secure_installation

# Criar banco de dados
sudo mysql -u root -p -e "
CREATE DATABASE chatbotpa_db;
CREATE USER 'chatbotpa_user'@'localhost' IDENTIFIED BY 'sua_senha_aqui';
GRANT ALL PRIVILEGES ON chatbotpa_db.* TO 'chatbotpa_user'@'localhost';
FLUSH PRIVILEGES;
"

# Instalar Gunicorn
sudo apt install python3-gunicorn -y

# Configurar Nginx
sudo cp nginx_config.conf /etc/nginx/sites-available/zap.oncristo.com.br
sudo ln -s /etc/nginx/sites-available/zap.oncristo.com.br /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default

# Configurar SSL
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d zap.oncristo.com.br

# Configurar firewall
sudo ufw allow 'Nginx Full'
sudo ufw allow OpenSSH
sudo ufw enable

echo "✅ Instalação concluída!"
EOF

print_status "Script de instalação criado!"

# 6. CRIAR ARQUIVO DE DEPLOY FINAL
print_info "6. Criando script de deploy final..."

cat > deploy_final.sh << 'EOF'
#!/bin/bash

# Script para deploy final da aplicação
echo "🚀 DEPLOY FINAL DA APLICAÇÃO"

cd /home/ubuntu/chatbotpa

# Criar ambiente virtual
python3 -m venv venv
source venv/bin/activate

# Instalar dependências
pip install -r requirements.txt
pip install gunicorn

# Copiar arquivo de produção
cp .env.production .env

# Configurar serviço
sudo cp chatbotpa.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable chatbotpa
sudo systemctl start chatbotpa

# Reiniciar Nginx
sudo systemctl restart nginx

# Verificar status
sudo systemctl status chatbotpa
sudo systemctl status nginx

echo "✅ Deploy concluído!"
echo "🌐 Acesse: https://zap.oncristo.com.br"
EOF

print_status "Script de deploy final criado!"

# 7. CRIAR ARQUIVO DE INSTRUÇÕES
print_info "7. Criando instruções de deploy..."

cat > INSTRUCOES_DEPLOY.md << EOF
# 🚀 INSTRUÇÕES DE DEPLOY PARA DIGITALOCEAN

## 📋 ARQUIVOS CRIADOS:

1. **.env.production** - Configurações para produção
2. **nginx_config.conf** - Configuração do Nginx
3. **chatbotpa.service** - Serviço systemd
4. **install_on_server.sh** - Script de instalação
5. **deploy_final.sh** - Script de deploy final

## 🎯 PASSOS PARA DEPLOY:

### 1. Upload dos arquivos para o servidor:
\`\`\`bash
# No seu computador local
scp -r . ubuntu@SEU_IP_DO:/home/ubuntu/chatbotpa/
\`\`\`

### 2. Instalar no servidor:
\`\`\`bash
# No servidor DigitalOcean
cd /home/ubuntu/chatbotpa
chmod +x install_on_server.sh
./install_on_server.sh
\`\`\`

### 3. Deploy final:
\`\`\`bash
# No servidor DigitalOcean
chmod +x deploy_final.sh
./deploy_final.sh
\`\`\`

## 🔧 CONFIGURAÇÕES IMPORTANTES:

### Banco de dados:
- **Host:** localhost
- **Database:** chatbotpa_db
- **User:** chatbotpa_user
- **Password:** (definir no script)

### Domínio:
- **URL:** https://zap.oncristo.com.br
- **SSL:** Automático via Certbot

### Serviço:
- **Porta:** 5000 (interno)
- **Nginx:** Proxy para porta 80/443
- **Gunicorn:** 3 workers

## 📞 TROUBLESHOOTING:

### Verificar logs:
\`\`\`bash
sudo journalctl -u chatbotpa -f
sudo tail -f /var/log/nginx/error.log
\`\`\`

### Reiniciar serviços:
\`\`\`bash
sudo systemctl restart chatbotpa
sudo systemctl restart nginx
\`\`\`

### Verificar status:
\`\`\`bash
sudo systemctl status chatbotpa
sudo systemctl status nginx
\`\`\`

## 🎉 SUCESSO!

Após o deploy, o webhook estará disponível em:
**https://zap.oncristo.com.br**

EOF

print_status "Instruções de deploy criadas!"

echo ""
print_success "🎉 ARQUIVOS DE DEPLOY CRIADOS COM SUCESSO!"
echo ""
print_info "📋 PRÓXIMOS PASSOS:"
echo "   1. Configure o IP do servidor no script"
echo "   2. Upload dos arquivos para o servidor"
echo "   3. Execute install_on_server.sh"
echo "   4. Execute deploy_final.sh"
echo ""
print_info "📁 ARQUIVOS CRIADOS:"
echo "   📄 .env.production"
echo "   📄 nginx_config.conf"
echo "   📄 chatbotpa.service"
echo "   📄 install_on_server.sh"
echo "   📄 deploy_final.sh"
echo "   📄 INSTRUCOES_DEPLOY.md"
echo ""
print_warning "⚠️  IMPORTANTE:"
echo "   - Configure a senha do banco MySQL"
echo "   - Atualize o IP do servidor"
echo "   - Verifique as chaves da API WhatsApp"
