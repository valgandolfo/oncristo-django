from django.apps import AppConfig


class AppIgrejaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_igreja'
