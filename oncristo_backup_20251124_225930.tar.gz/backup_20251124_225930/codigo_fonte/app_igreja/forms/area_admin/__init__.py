# Formulários da área administrativa

from .forms_celebracoes import CelebracaoForm

__all__ = [
    'CelebracaoForm',
]
