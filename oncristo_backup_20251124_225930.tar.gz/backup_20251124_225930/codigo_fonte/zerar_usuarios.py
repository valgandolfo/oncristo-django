#!/usr/bin/env python
"""
Script para deletar todos os usuários do banco de dados
Execute: python zerar_usuarios.py
"""
import os
import django

# Configurar Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'pro_igreja.settings')
django.setup()

from django.contrib.auth.models import User

print("=" * 50)
print("  DELETANDO TODOS OS USUÁRIOS")
print("=" * 50)
print()

# Contar usuários antes
total_antes = User.objects.count()
print(f"📊 Total de usuários antes: {total_antes}")

if total_antes == 0:
    print("✅ Nenhum usuário para deletar!")
    exit(0)

# Listar usuários que serão deletados
print("\n👥 Usuários que serão deletados:")
for user in User.objects.all():
    print(f"   - ID: {user.id} | Username: {user.username} | Email: {user.email}")

# Confirmar
print("\n⚠️  ATENÇÃO: Esta ação não pode ser desfeita!")
resposta = input("Deseja continuar? (digite 'SIM' para confirmar): ")

if resposta != 'SIM':
    print("❌ Operação cancelada!")
    exit(0)

# Deletar todos os usuários
User.objects.all().delete()

# Verificar
total_depois = User.objects.count()
print(f"\n✅ Usuários deletados com sucesso!")
print(f"📊 Total de usuários depois: {total_depois}")

print("\n" + "=" * 50)
print("  PRÓXIMOS PASSOS:")
print("=" * 50)
print("1. Execute: python manage.py createsuperuser")
print("2. Crie um novo superusuário")
print("3. Use o USERNAME para fazer login")
print("=" * 50)

