# 🔐 Configurar SSH para Digital Ocean

## 📋 Passo 1: Gerar Chave SSH (se não tiver)

Execute no seu terminal:

```bash
ssh-keygen -t ed25519 -C "seu-email@exemplo.com"
```

**Quando perguntar:**
- **Onde salvar?** → Pressione Enter (usa o padrão: `~/.ssh/id_ed25519`)
- **Senha?** → Pode deixar vazio (Enter) ou criar uma senha

**Resultado:** Vai criar duas chaves:
- `~/.ssh/id_ed25519` (chave privada - NUNCA compartilhe!)
- `~/.ssh/id_ed25519.pub` (chave pública - essa você vai adicionar no servidor)

---

## 📋 Passo 2: Ver a Chave Pública

Execute para ver sua chave pública:

```bash
cat ~/.ssh/id_ed25519.pub
```

**Copie todo o conteúdo** (começa com `ssh-ed25519` e termina com seu email)

---

## 📋 Passo 3: Adicionar Chave no Digital Ocean

### Opção A: Via Painel Digital Ocean (Recomendado)

1. Acesse: https://cloud.digitalocean.com/account/security
2. Clique em **"Add SSH Key"**
3. Cole a chave pública que você copiou
4. Dê um nome (ex: "Meu Computador")
5. Clique em **"Add SSH Key"**

### Opção B: Adicionar no Droplet Específico

1. Acesse seu droplet: `projeto-on-cristo`
2. Vá em **Settings** → **Security**
3. Adicione a chave SSH

---

## 📋 Passo 4: Conectar ao Servidor

Depois de adicionar a chave, conecte:

```bash
ssh root@137.184.116.197
```

**Se funcionar:** Você vai entrar direto (sem pedir senha) ✅

**Se pedir senha:** Use a senha que você configurou no Digital Ocean

---

## 🔧 Passo 5: Configurar Acesso por Senha (Alternativa)

Se preferir usar senha ao invés de chave SSH:

1. No Digital Ocean, acesse seu droplet
2. Clique em **"Access"** → **"Launch Droplet Console"**
3. Entre com usuário `root` e a senha que você configurou
4. Ou use a senha que foi enviada por email quando criou o droplet

---

## ✅ Testar Conexão

Depois de configurar, teste:

```bash
ssh root@137.184.116.197 "echo 'Conexão OK!'"
```

Se aparecer "Conexão OK!", está funcionando! 🎉

---

## 🆘 Problemas Comuns

**Erro: "Permission denied"**
- Verifique se a chave foi adicionada corretamente no Digital Ocean
- Tente usar senha: `ssh root@137.184.116.197` (vai pedir senha)

**Erro: "Host key verification failed"**
- Execute: `ssh-keygen -R 137.184.116.197`

**Não consegue conectar**
- Verifique se o droplet está rodando no painel Digital Ocean
- Verifique o firewall do servidor

