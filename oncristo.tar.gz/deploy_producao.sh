#!/bin/bash

# ============================================
# Script de Deploy para Produção - OnCristo
# ============================================

set -e

echo "🚀 Deploy OnCristo - Digital Ocean"
echo "===================================="

# Cores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_info() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

# Verificar se está no diretório correto
if [ ! -f "manage.py" ]; then
    print_error "Execute este script no diretório raiz do projeto"
    exit 1
fi

# Verificar ambiente virtual
if [ ! -d "venv" ]; then
    print_warning "Ambiente virtual não encontrado. Criando..."
    python3.12 -m venv venv
fi

# Ativar ambiente virtual
print_info "Ativando ambiente virtual..."
source venv/bin/activate

# Verificar .env_production
if [ ! -f ".env_production" ]; then
    print_error "Arquivo .env_production não encontrado!"
    print_info "Copie o .env_production.example e configure com suas credenciais"
    exit 1
fi

# Carregar variáveis de ambiente
export DJANGO_ENV=production
export $(grep -v '^#' .env_production | xargs)

# Instalar/Atualizar dependências
print_info "Instalando dependências..."
pip install --upgrade pip
pip install -r requirements.txt

# Aplicar migrações
print_info "Aplicando migrações do banco de dados..."
python manage.py migrate --noinput

# Coletar arquivos estáticos
print_info "Coletando arquivos estáticos..."
python manage.py collectstatic --noinput

# Verificar configuração
print_info "Verificando configuração do Django..."
python manage.py check --deploy

# Reiniciar Gunicorn
if systemctl is-active --quiet gunicorn_oncristo; then
    print_info "Reiniciando Gunicorn..."
    sudo systemctl restart gunicorn_oncristo
    print_info "Status do Gunicorn:"
    sudo systemctl status gunicorn_oncristo --no-pager -l
else
    print_warning "Gunicorn não está rodando como serviço"
    print_info "Para iniciar: sudo systemctl start gunicorn_oncristo"
fi

# Verificar Nginx
if systemctl is-active --quiet nginx; then
    print_info "Testando configuração do Nginx..."
    sudo nginx -t && {
        sudo systemctl reload nginx
        print_info "Nginx recarregado com sucesso!"
    } || {
        print_error "Erro na configuração do Nginx"
    }
else
    print_warning "Nginx não está rodando"
fi

print_info "✅ Deploy concluído!"
print_info "Acesse: https://oncristo.com.br"

