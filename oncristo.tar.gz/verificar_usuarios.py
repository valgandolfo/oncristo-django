#!/usr/bin/env python3
"""
Script para verificar usuários no sistema
Execute: python verificar_usuarios.py
"""

import os
import sys
import django

# Configurar Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'pro_igreja.settings')
django.setup()

from django.contrib.auth import get_user_model

User = get_user_model()

def verificar_usuarios():
    """Lista todos os usuários e detalhes dos administradores"""
    print("🔍 VERIFICANDO USUÁRIOS NO SISTEMA")
    print("=" * 50)
    
    # Buscar todos os usuários
    usuarios = User.objects.all()
    
    if not usuarios.exists():
        print("❌ Nenhum usuário encontrado no sistema!")
        print("💡 Execute: python create_superuser.py")
        return
    
    print(f"📊 Total de usuários: {usuarios.count()}")
    print()
    
    # Listar todos os usuários
    print("👥 TODOS OS USUÁRIOS:")
    print("-" * 50)
    
    for i, user in enumerate(usuarios, 1):
        print(f"{i}. ID: {user.id}")
        print(f"   📧 Email: {user.email}")
        print(f"   👤 Username: {user.username}")
        print(f"   👑 Superuser: {user.is_superuser}")
        print(f"   👨‍💼 Staff: {user.is_staff}")
        print(f"   ✅ Ativo: {user.is_active}")
        print(f"   📅 Criado: {user.date_joined}")
        print(f"   🔗 Último login: {user.last_login}")
        print()
    
    # Filtrar apenas administradores
    admins = usuarios.filter(is_superuser=True)
    
    if admins.exists():
        print("👑 USUÁRIOS ADMINISTRADORES:")
        print("-" * 50)
        
        for i, admin in enumerate(admins, 1):
            print(f"{i}. ID: {admin.id}")
            print(f"   📧 Email: {admin.email}")
            print(f"   👤 Username: {admin.username}")
            print(f"   👑 Superuser: {admin.is_superuser}")
            print(f"   👨‍💼 Staff: {admin.is_staff}")
            print(f"   ✅ Ativo: {admin.is_active}")
            print(f"   📅 Criado: {admin.date_joined}")
            print(f"   🔗 Último login: {admin.last_login}")
            print()
    else:
        print("❌ Nenhum usuário administrador encontrado!")
        print("💡 Execute: python create_superuser.py")
    
    # Mostrar usuários staff (não superuser)
    staff_users = usuarios.filter(is_staff=True, is_superuser=False)
    
    if staff_users.exists():
        print("👨‍💼 USUÁRIOS STAFF (NÃO SUPERUSER):")
        print("-" * 50)
        
        for i, staff in enumerate(staff_users, 1):
            print(f"{i}. ID: {staff.id}")
            print(f"   📧 Email: {staff.email}")
            print(f"   👤 Username: {staff.username}")
            print(f"   👑 Superuser: {staff.is_superuser}")
            print(f"   👨‍💼 Staff: {staff.is_staff}")
            print(f"   ✅ Ativo: {staff.is_active}")
            print()
    
    # Mostrar usuários normais
    normal_users = usuarios.filter(is_staff=False, is_superuser=False)
    
    if normal_users.exists():
        print("👤 USUÁRIOS NORMAIS:")
        print("-" * 50)
        
        for i, normal in enumerate(normal_users, 1):
            print(f"{i}. ID: {normal.id}")
            print(f"   📧 Email: {normal.email}")
            print(f"   👤 Username: {normal.username}")
            print(f"   ✅ Ativo: {normal.is_active}")
            print()
    
    print("=" * 50)
    print("💡 Para criar novo superusuário: python create_superuser.py")
    print("💡 Para resetar senha: python debug_login.py")

if __name__ == "__main__":
    verificar_usuarios()
