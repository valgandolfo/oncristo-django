# 🚀 Guia de Deploy - Digital Ocean

## 📋 Checklist Pré-Deploy

### ✅ O que você já tem:
- [x] Domínio configurado
- [x] Acesso a banco de dados
- [x] Projeto Django funcional
- [x] AWS S3 configurado (para mídia)

### 📦 O que você precisa:

1. **Droplet Digital Ocean**
   - Ubuntu 22.04 LTS (recomendado)
   - Mínimo: 1GB RAM, 1 vCPU
   - Recomendado: 2GB RAM, 1 vCPU

2. **Banco de Dados**
   - PostgreSQL (recomendado) ou MySQL
   - Credenciais de acesso

3. **Credenciais AWS S3**
   - `AWS_ACCESS_KEY_ID`
   - `AWS_SECRET_ACCESS_KEY`
   - `AWS_STORAGE_BUCKET_NAME`
   - `AWS_S3_REGION_NAME`

4. **Domínio**
   - DNS configurado apontando para IP do droplet
   - Exemplo: `paroquia.com.br` → `123.456.789.0`

---

## 🔧 Passo 1: Preparar Settings para Produção

### Criar arquivo `.env_production`:

```bash
# .env_production
# ============================================
# CONFIGURAÇÕES DE PRODUÇÃO
# ============================================

# Django
SECRET_KEY=sua-chave-secreta-super-forte-aqui-gerar-com-django-secret-key
DEBUG=False
ALLOWED_HOSTS=seudominio.com.br,www.seudominio.com.br

# Banco de Dados
DB_ENGINE=django.db.backends.postgresql
DB_NAME=nome_do_banco
DB_USER=usuario_banco
DB_PASSWORD=senha_banco
DB_HOST=host_do_banco
DB_PORT=5432

# AWS S3
AWS_ACCESS_KEY_ID=sua_access_key
AWS_SECRET_ACCESS_KEY=sua_secret_key
AWS_STORAGE_BUCKET_NAME=nome_do_bucket
AWS_S3_REGION_NAME=us-east-1

# Email (opcional)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=seu_email@gmail.com
EMAIL_HOST_PASSWORD=sua_senha_app
```

### Atualizar `settings.py`:

```python
# Adicionar no início do settings.py
import os
from pathlib import Path
from dotenv import load_dotenv

# Carregar .env baseado no ambiente
if os.getenv('DJANGO_ENV') == 'production':
    load_dotenv('.env_production')
else:
    load_dotenv('.env_local')

# ALLOWED_HOSTS - Produção
if os.getenv('DJANGO_ENV') == 'production':
    ALLOWED_HOSTS = os.getenv('ALLOWED_HOSTS', '').split(',')
else:
    ALLOWED_HOSTS = ['*', 'localhost', '127.0.0.1']
```

---

## 📦 Passo 2: Criar requirements.txt

```bash
# Gerar requirements.txt
pip freeze > requirements.txt
```

**Dependências essenciais:**
```
Django==5.0.3
django-storages==1.14.2
boto3==1.34.0
psycopg2-binary==2.9.9  # Para PostgreSQL
gunicorn==21.2.0
whitenoise==6.6.0  # Para servir static files
python-dotenv==1.0.0
```

---

## 🖥️ Passo 3: Configurar Servidor (Digital Ocean)

### 3.1. Conectar ao servidor:
```bash
ssh root@seu_ip_digital_ocean
```

### 3.2. Atualizar sistema:
```bash
apt update && apt upgrade -y
```

### 3.3. Instalar dependências:
```bash
# Python e pip
apt install -y python3 python3-pip python3-venv python3-dev

# PostgreSQL client (se usar PostgreSQL)
apt install -y postgresql-client libpq-dev

# Nginx
apt install -y nginx

# Git
apt install -y git

# Build essentials (para compilar algumas dependências)
apt install -y build-essential
```

### 3.4. Criar usuário para aplicação:
```bash
adduser --disabled-password --gecos "" django
usermod -aG sudo django
su - django
```

### 3.5. Clonar/copiar projeto:
```bash
# Opção 1: Via Git
git clone seu_repositorio.git /home/django/oncristo
cd /home/django/oncristo

# Opção 2: Via SCP (do seu PC)
# No seu PC local:
# scp -r /home/joaonote/oncristo.local/* django@seu_ip:/home/django/oncristo/
```

### 3.6. Configurar ambiente virtual:
```bash
cd /home/django/oncristo
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

### 3.7. Configurar arquivo .env_production:
```bash
nano .env_production
# Cole o conteúdo do .env_production criado anteriormente
```

### 3.8. Configurar settings.py para produção:
```bash
# Adicionar no início do settings.py
export DJANGO_ENV=production
```

---

## 🗄️ Passo 4: Configurar Banco de Dados

### 4.1. Criar banco de dados (se necessário):
```bash
# Conectar ao PostgreSQL
psql -h seu_host -U seu_usuario -d postgres

# Criar banco
CREATE DATABASE nome_do_banco;
CREATE USER usuario_banco WITH PASSWORD 'senha_banco';
GRANT ALL PRIVILEGES ON DATABASE nome_do_banco TO usuario_banco;
\q
```

### 4.2. Executar migrações:
```bash
cd /home/django/oncristo
source venv/bin/activate
export DJANGO_ENV=production
python manage.py migrate
```

### 4.3. Coletar arquivos estáticos:
```bash
python manage.py collectstatic --noinput
```

### 4.4. Criar superusuário:
```bash
python manage.py createsuperuser
```

---

## 🔒 Passo 5: Configurar Gunicorn

### 5.1. Criar arquivo de serviço systemd:
```bash
sudo nano /etc/systemd/system/gunicorn.service
```

**Conteúdo:**
```ini
[Unit]
Description=gunicorn daemon for oncristo
After=network.target

[Service]
User=django
Group=www-data
WorkingDirectory=/home/django/oncristo
Environment="DJANGO_ENV=production"
Environment="PATH=/home/django/oncristo/venv/bin"
ExecStart=/home/django/oncristo/venv/bin/gunicorn \
    --access-logfile - \
    --workers 3 \
    --bind unix:/home/django/oncristo/gunicorn.sock \
    pro_igreja.wsgi:application

[Install]
WantedBy=multi-user.target
```

### 5.2. Iniciar e habilitar Gunicorn:
```bash
sudo systemctl daemon-reload
sudo systemctl start gunicorn
sudo systemctl enable gunicorn
sudo systemctl status gunicorn
```

---

## 🌐 Passo 6: Configurar Nginx

### 6.1. Criar configuração do Nginx:
```bash
sudo nano /etc/nginx/sites-available/oncristo
```

**Conteúdo:**
```nginx
server {
    listen 80;
    server_name seudominio.com.br www.seudominio.com.br;

    # Redirecionar HTTP para HTTPS (após configurar SSL)
    # return 301 https://$server_name$request_uri;

    # Após configurar SSL, descomente acima e use abaixo:
    # listen 443 ssl http2;
    # ssl_certificate /etc/letsencrypt/live/seudominio.com.br/fullchain.pem;
    # ssl_certificate_key /etc/letsencrypt/live/seudominio.com.br/privkey.pem;

    location = /favicon.ico { access_log off; log_not_found off; }

    location /static/ {
        alias /home/django/oncristo/staticfiles/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    location /media/ {
        alias /home/django/oncristo/media/;
        expires 30d;
        add_header Cache-Control "public";
    }

    location / {
        include proxy_params;
        proxy_pass http://unix:/home/django/oncristo/gunicorn.sock;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Tamanho máximo de upload (para imagens)
    client_max_body_size 10M;
}
```

### 6.2. Ativar site:
```bash
sudo ln -s /etc/nginx/sites-available/oncristo /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

---

## 🔐 Passo 7: Configurar SSL (Let's Encrypt)

### 7.1. Instalar Certbot:
```bash
sudo apt install -y certbot python3-certbot-nginx
```

### 7.2. Obter certificado SSL:
```bash
sudo certbot --nginx -d seudominio.com.br -d www.seudominio.com.br
```

### 7.3. Renovação automática:
```bash
# Já configurado automaticamente pelo certbot
sudo certbot renew --dry-run
```

---

## 📝 Passo 8: Script de Deploy

### Criar `deploy.sh`:
```bash
nano /home/django/oncristo/deploy.sh
```

**Conteúdo:**
```bash
#!/bin/bash
set -e

echo "🚀 Iniciando deploy..."

# Ativar ambiente virtual
source /home/django/oncristo/venv/bin/activate
export DJANGO_ENV=production

# Ir para diretório do projeto
cd /home/django/oncristo

# Atualizar código (se usar Git)
# git pull origin main

# Instalar/atualizar dependências
pip install -r requirements.txt

# Executar migrações
python manage.py migrate --noinput

# Coletar arquivos estáticos
python manage.py collectstatic --noinput

# Reiniciar Gunicorn
sudo systemctl restart gunicorn

# Testar Nginx
sudo nginx -t && sudo systemctl reload nginx

echo "✅ Deploy concluído!"
```

**Tornar executável:**
```bash
chmod +x /home/django/oncristo/deploy.sh
```

---

## 🔍 Passo 9: Verificações Finais

### 9.1. Verificar serviços:
```bash
# Gunicorn
sudo systemctl status gunicorn

# Nginx
sudo systemctl status nginx

# Logs
sudo journalctl -u gunicorn -f
sudo tail -f /var/log/nginx/error.log
```

### 9.2. Testar aplicação:
```bash
# No navegador
https://seudominio.com.br

# Verificar se está funcionando
curl -I https://seudominio.com.br
```

### 9.3. Verificar banco de dados:
```bash
cd /home/django/oncristo
source venv/bin/activate
export DJANGO_ENV=production
python manage.py dbshell
```

---

## 📋 Checklist de Deploy

- [ ] Droplet Digital Ocean criado
- [ ] Domínio apontando para IP do droplet
- [ ] Banco de dados criado e acessível
- [ ] Arquivo `.env_production` configurado
- [ ] `settings.py` atualizado para produção
- [ ] `requirements.txt` criado
- [ ] Servidor atualizado (apt update)
- [ ] Python, pip, venv instalados
- [ ] PostgreSQL client instalado (se usar PostgreSQL)
- [ ] Nginx instalado
- [ ] Projeto copiado para servidor
- [ ] Ambiente virtual criado e dependências instaladas
- [ ] Migrações executadas
- [ ] Arquivos estáticos coletados
- [ ] Superusuário criado
- [ ] Gunicorn configurado e rodando
- [ ] Nginx configurado e rodando
- [ ] SSL configurado (Let's Encrypt)
- [ ] Firewall configurado (portas 80, 443)
- [ ] Testes realizados
- [ ] Backup configurado

---

## 🔥 Comandos Úteis

### Reiniciar serviços:
```bash
sudo systemctl restart gunicorn
sudo systemctl restart nginx
```

### Ver logs:
```bash
# Gunicorn
sudo journalctl -u gunicorn -n 50

# Nginx
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# Django
tail -f /home/django/oncristo/logs/django.log  # Se configurar logging
```

### Executar comandos Django:
```bash
cd /home/django/oncristo
source venv/bin/activate
export DJANGO_ENV=production
python manage.py [comando]
```

### Backup do banco:
```bash
# PostgreSQL
pg_dump -h host -U usuario nome_banco > backup_$(date +%Y%m%d).sql

# Restaurar
psql -h host -U usuario nome_banco < backup_20241116.sql
```

---

## ⚠️ Segurança

### 1. Firewall (UFW):
```bash
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS
sudo ufw enable
sudo ufw status
```

### 2. Permissões de arquivos:
```bash
# Proprietário correto
sudo chown -R django:www-data /home/django/oncristo
sudo chmod -R 755 /home/django/oncristo
sudo chmod -R 775 /home/django/oncristo/media
sudo chmod -R 775 /home/django/oncristo/staticfiles
```

### 3. SECRET_KEY:
```bash
# Gerar nova SECRET_KEY
python -c "from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())"
```

---

## 🐛 Troubleshooting

### Erro: "DisallowedHost"
- Verificar `ALLOWED_HOSTS` no `.env_production`
- Verificar se domínio está correto

### Erro: "No module named 'psycopg2'"
```bash
pip install psycopg2-binary
```

### Erro: "Static files not found"
```bash
python manage.py collectstatic --noinput
sudo chown -R django:www-data staticfiles/
```

### Erro: "Permission denied"
```bash
sudo chown -R django:www-data /home/django/oncristo
```

### Gunicorn não inicia:
```bash
sudo journalctl -u gunicorn -n 50
# Verificar caminhos e permissões
```

---

## 📞 Suporte

Em caso de problemas:
1. Verificar logs: `sudo journalctl -u gunicorn -n 100`
2. Verificar Nginx: `sudo nginx -t`
3. Testar localmente: `python manage.py runserver`
4. Verificar banco de dados: `python manage.py dbshell`

---

**Boa sorte com o deploy! 🚀**

