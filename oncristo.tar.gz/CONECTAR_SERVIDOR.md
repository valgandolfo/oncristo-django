# 🔌 Conectar ao Servidor Digital Ocean

## 📋 Informações do Servidor:
- **IP**: 137.184.116.197
- **Usuário**: root (ou o usuário que você criou)
- **Porta SSH**: 22 (padrão)

---

## 🔑 Passo 1: Conectar via SSH

Execute no seu terminal local:

```bash
ssh root@137.184.116.197
```

**Se pedir senha:**
- Use a senha que você configurou no Digital Ocean
- Ou use a chave SSH se você configurou

**Se pedir confirmação (first time):**
- Digite `yes` e pressione Enter

---

## ✅ Passo 2: Verificar se está conectado

Depois de conectar, você deve ver algo como:

```
root@ubuntu-s-1vcpu-512mb-10gb-sfo3-01:~#
```

**Se aparecer isso, você está conectado!** ✅

---

## 🚀 Próximos Passos (depois de conectar):

1. Atualizar sistema
2. Instalar dependências (Python, pip, etc)
3. Transferir projeto para o servidor
4. Configurar ambiente virtual
5. Configurar Gunicorn e Nginx

---

## 💡 Dica:

Se você já tem Gunicorn rodando (como mencionou), podemos verificar o que já está configurado!

