# 📦 Transferir Projeto para o Servidor

## ✅ Status:
- ✅ Gunicorn instalado
- ✅ Python instalado
- ✅ Nginx instalado

---

## 📋 PASSO 1: Preparar projeto no seu PC LOCAL

**No seu computador local**, execute:

```bash
cd /home/joaonote/oncristo.local

# Criar arquivo compactado (sem venv e arquivos desnecessários)
tar --exclude='venv' \
    --exclude='__pycache__' \
    --exclude='*.pyc' \
    --exclude='.git' \
    --exclude='db.sqlite3' \
    --exclude='media' \
    --exclude='staticfiles' \
    -czf oncristo.tar.gz .
```

---

## 📋 PASSO 2: Transferir para o servidor

**Ainda no seu PC LOCAL**, execute:

```bash
# Transferir arquivo
scp oncristo.tar.gz root@137.184.116.197:/root/
```

**Vai pedir senha do servidor** - digite a senha do root.

---

## 📋 PASSO 3: No servidor - Descompactar

**No terminal do servidor (DO)**, execute:

```bash
# Criar diretório
mkdir -p /home/oncristo
cd /home/oncristo

# Descompactar
tar -xzf /root/oncristo.tar.gz

# Verificar se descompactou
ls -la
```

---

## 📋 PASSO 4: Verificar arquivos importantes

```bash
# Verificar se tem manage.py
ls manage.py

# Verificar se tem requirements.txt
ls requirements.txt

# Verificar se tem .env_production
ls .env_production
```

---

## 🎯 EXECUTE AGORA:

**1. No seu PC LOCAL:**
```bash
cd /home/joaonote/oncristo.local
tar --exclude='venv' --exclude='__pycache__' --exclude='*.pyc' --exclude='.git' --exclude='db.sqlite3' --exclude='media' --exclude='staticfiles' -czf oncristo.tar.gz .
scp oncristo.tar.gz root@137.184.116.197:/root/
```

**2. No servidor (terminal DO):**
```bash
mkdir -p /home/oncristo
cd /home/oncristo
tar -xzf /root/oncristo.tar.gz
ls -la
```

**Me diga quando terminar!**

