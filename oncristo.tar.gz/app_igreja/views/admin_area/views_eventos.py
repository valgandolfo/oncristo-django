from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q, Count
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.urls import reverse
from datetime import datetime, timedelta, date


from app_igreja.models.area_admin.models_eventos import TBEVENTO
from app_igreja.forms.area_admin.forms_eventos import EventoForm


@login_required
def listar_eventos(request):
    """
    Lista todos os eventos com paginação e busca
    """
    # Parâmetros de busca
    busca = request.GET.get('busca', '')
    status = request.GET.get('status', '')
    
    # Query base
    eventos = TBEVENTO.objects.all().order_by('-EVE_DTCADASTRO')
    
    # Filtros
    if busca:
        eventos = eventos.filter(
            Q(EVE_TITULO__icontains=busca)
        )
    
    if status:
        eventos = eventos.filter(EVE_STATUS=status)
    
    # Paginação
    paginator = Paginator(eventos, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    # Estatísticas
    total_eventos = TBEVENTO.objects.count()
    ativos = TBEVENTO.objects.filter(EVE_STATUS='Ativo').count()
    inativos = TBEVENTO.objects.filter(EVE_STATUS='Inativo').count()
    
    # Eventos recentes (últimos 5)
    eventos_recentes = TBEVENTO.objects.filter(
        EVE_STATUS='Ativo'
    ).order_by('-EVE_DTCADASTRO')[:5]
    
    # Eventos do mês atual
    hoje = date.today()
    eventos_mes = TBEVENTO.objects.filter(
        EVE_DTCADASTRO__year=hoje.year,
        EVE_DTCADASTRO__month=hoje.month
    ).count()
    
    context = {
        'page_obj': page_obj,
        'busca': busca,
        'status': status,
        'total_eventos': total_eventos,
        'ativos': ativos,
        'inativos': inativos,
        'eventos_recentes': eventos_recentes,
        'eventos_mes': eventos_mes,
        'modo_dashboard': True,  # Migrado para nova tela pai dashboard
        'model_verbose_name': 'Evento',
    }
    
    return render(request, 'admin_area/tpl_eventos.html', context)


@login_required
def criar_evento(request):
    """
    Cria um novo evento
    """
    if request.method == 'POST':
        form = EventoForm(request.POST)
        if form.is_valid():
            evento = form.save()
            messages.success(request, 'Evento criado com sucesso!')
            return redirect('app_igreja:listar_eventos')
    else:
        form = EventoForm()
    
    # Usar HTTP_REFERER como fallback, igual ao dizimistas
    next_url = request.META.get('HTTP_REFERER') or reverse('app_igreja:listar_eventos')
    
    context = {
        'form': form,
        'acao': 'incluir',
        'model_verbose_name': 'Evento',
        'next_url': next_url,
        'modo_detalhe': True,
        'eventos_section': 'detail',  # Seção: CRUD básico
    }
    
    return render(request, 'admin_area/tpl_eventos.html', context)


@login_required
def detalhar_evento(request, evento_id):
    """
    Visualiza os detalhes de um evento
    """
    evento = get_object_or_404(TBEVENTO, EVE_ID=evento_id)
    
    # Usar HTTP_REFERER como fallback, igual ao dizimistas
    next_url = request.META.get('HTTP_REFERER') or reverse('app_igreja:listar_eventos')
    
    context = {
        'evento': evento,
        'acao': 'consultar',
        'model_verbose_name': 'Evento',
        'next_url': next_url,
        'modo_detalhe': True,
        'eventos_section': 'detail',  # Seção: CRUD básico
    }
    
    return render(request, 'admin_area/tpl_eventos.html', context)


@login_required
def editar_evento(request, evento_id):
    """
    Edita um evento existente
    """
    evento = get_object_or_404(TBEVENTO, EVE_ID=evento_id)
    
    if request.method == 'POST':
        form = EventoForm(request.POST, instance=evento)
        if form.is_valid():
            form.save()
            messages.success(request, 'Evento atualizado com sucesso!')
            return redirect('app_igreja:listar_eventos')
    else:
        form = EventoForm(instance=evento)
    
    # Usar HTTP_REFERER como fallback, igual ao dizimistas
    next_url = request.META.get('HTTP_REFERER') or reverse('app_igreja:listar_eventos')
    
    context = {
        'form': form,
        'evento': evento,
        'acao': 'editar',
        'model_verbose_name': 'Evento',
        'next_url': next_url,
        'modo_detalhe': True,
        'eventos_section': 'detail',  # Seção: CRUD básico
    }
    
    return render(request, 'admin_area/tpl_eventos.html', context)


@login_required
def excluir_evento(request, evento_id):
    """
    Exclui um evento
    """
    evento = get_object_or_404(TBEVENTO, EVE_ID=evento_id)
    
    if request.method == 'POST':
        evento.delete()
        messages.success(request, 'Evento excluído com sucesso!')
        return redirect('app_igreja:listar_eventos')
    
    # Usar HTTP_REFERER como fallback, igual ao dizimistas
    next_url = request.META.get('HTTP_REFERER') or reverse('app_igreja:listar_eventos')
    
    context = {
        'evento': evento,
        'acao': 'excluir',
        'model_verbose_name': 'Evento',
        'next_url': next_url,
        'modo_detalhe': True,
        'eventos_section': 'detail',  # Seção: CRUD básico
    }
    
    return render(request, 'admin_area/tpl_eventos.html', context)

