"""
==================== API WHATSAPP - CHATBOT ====================
API para receber webhooks do WhatsApp e processar comandos do chatbot
Integra com módulos existentes: Dizimistas, Liturgias, Celebrações, etc.
"""

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.utils import timezone
from datetime import date, datetime
import json
import logging
import re

from ...models.area_admin.models_dizimistas import TBDIZIMISTAS
from ...models.area_publica.models_liturgias import TBLITURGIA
from ...models.area_admin.models_celebracoes import TBCELEBRACOES
from ...models.area_admin.models_oracoes import TBORACOES
from ...models.area_admin.models_paroquias import TBPAROQUIA
from ...forms.area_publica.forms_dizimistas import DizimistaPublicoForm

logger = logging.getLogger(__name__)


class WhatsAppChatbot:
    """
    Classe principal para processar mensagens do WhatsApp
    """
    
    def __init__(self):
        self.comandos = {
            'menu': self.menu_principal,
            'dizimista': self.cadastro_dizimista,
            'liturgia': self.consulta_liturgia,
            'horarios': self.horarios_missa,
            'eventos': self.eventos_paroquia,
            'oracao': self.pedido_oracao,
            'contato': self.contato_paroquia,
            'ajuda': self.menu_principal,
        }
    
    def processar_mensagem(self, mensagem_texto, telefone_remetente, nome_remetente=None):
        """
        Processa mensagem recebida e retorna resposta
        """
        mensagem_texto = mensagem_texto.strip().lower()
        
        # Remover acentos e caracteres especiais para comparação
        mensagem_limpa = self._normalizar_texto(mensagem_texto)
        
        # Verificar comandos diretos
        for comando, funcao in self.comandos.items():
            if mensagem_limpa.startswith(comando) or mensagem_limpa == comando:
                return funcao(telefone_remetente, nome_remetente, mensagem_texto)
        
        # Verificar palavras-chave
        if any(palavra in mensagem_limpa for palavra in ['quero ser dizimista', 'cadastrar dizimista', 'ser dizimista']):
            return self.cadastro_dizimista(telefone_remetente, nome_remetente, mensagem_texto)
        
        if any(palavra in mensagem_limpa for palavra in ['liturgia', 'leitura', 'evangelho', 'salmos']):
            return self.consulta_liturgia(telefone_remetente, nome_remetente, mensagem_texto)
        
        if any(palavra in mensagem_limpa for palavra in ['horario', 'missa', 'horários']):
            return self.horarios_missa(telefone_remetente, nome_remetente, mensagem_texto)
        
        if any(palavra in mensagem_limpa for palavra in ['evento', 'eventos', 'programação']):
            return self.eventos_paroquia(telefone_remetente, nome_remetente, mensagem_texto)
        
        if any(palavra in mensagem_limpa for palavra in ['oração', 'oracao', 'pedido']):
            return self.pedido_oracao(telefone_remetente, nome_remetente, mensagem_texto)
        
        if any(palavra in mensagem_limpa for palavra in ['contato', 'telefone', 'endereço', 'endereco']):
            return self.contato_paroquia(telefone_remetente, nome_remetente, mensagem_texto)
        
        # Mensagem padrão
        return self.menu_principal(telefone_remetente, nome_remetente, mensagem_texto)
    
    def _normalizar_texto(self, texto):
        """Normaliza texto removendo acentos"""
        import unicodedata
        texto = unicodedata.normalize('NFKD', texto)
        return ''.join(c for c in texto if not unicodedata.combining(c)).lower()
    
    def menu_principal(self, telefone, nome, mensagem):
        """Menu principal do chatbot"""
        resposta = f"""👋 Olá{f' {nome}' if nome else ''}! Bem-vindo à Paróquia!

📋 *MENU PRINCIPAL*

Escolha uma opção:

1️⃣ *DIZIMISTA* - Quero ser dizimista
2️⃣ *LITURGIA* - Liturgia do dia
3️⃣ *HORÁRIOS* - Horários de missas
4️⃣ *EVENTOS* - Eventos da paróquia
5️⃣ *ORAÇÃO* - Fazer pedido de oração
6️⃣ *CONTATO* - Informações de contato

Digite o número ou o nome da opção desejada.
"""
        return {'texto': resposta, 'tipo': 'texto'}
    
    def cadastro_dizimista(self, telefone, nome, mensagem):
        """
        Inicia processo de cadastro de dizimista via WhatsApp
        Reutiliza DizimistaPublicoForm
        """
        # Verificar se já está cadastrado
        try:
            dizimista_existente = TBDIZIMISTAS.objects.filter(DIS_telefone=telefone).first()
            if dizimista_existente:
                resposta = f"""✅ Você já está cadastrado como dizimista!

📝 *Seus dados:*
• Nome: {dizimista_existente.DIS_nome}
• Status: {'Ativo' if dizimista_existente.DIS_status else 'Pendente'}

Para atualizar seus dados, entre em contato com a secretaria.
"""
                return {'texto': resposta, 'tipo': 'texto'}
        except Exception as e:
            logger.error(f"Erro ao verificar dizimista: {e}")
        
        # Iniciar cadastro
        resposta = """📝 *CADASTRO DE DIZIMISTA*

Para se cadastrar, preciso de algumas informações:

1️⃣ *Nome completo*
2️⃣ *E-mail* (opcional)
3️⃣ *Data de nascimento* (opcional)
4️⃣ *CEP* (opcional)

Por favor, envie seu *nome completo* para começarmos.
"""
        return {'texto': resposta, 'tipo': 'texto', 'contexto': 'cadastro_dizimista_nome'}
    
    def consulta_liturgia(self, telefone, nome, mensagem):
        """
        Consulta liturgia do dia ou data específica
        Reutiliza get_liturgia_por_data
        """
        try:
            # Tentar extrair data da mensagem
            data_consulta = self._extrair_data(mensagem)
            if not data_consulta:
                data_consulta = date.today()
            
            # Buscar liturgias
            liturgias = TBLITURGIA.objects.filter(
                LIT_DATALIT=data_consulta,
                LIT_STATUSLIT=True
            ).order_by('LIT_TIPOLIT')
            
            if not liturgias.exists():
                resposta = f"""📖 *LITURGIA*

Não encontrei liturgia para a data {data_consulta.strftime('%d/%m/%Y')}.

Tente outra data ou digite *LITURGIA HOJE* para ver a de hoje.
"""
                return {'texto': resposta, 'tipo': 'texto'}
            
            # Montar resposta
            resposta = f"""📖 *LITURGIA - {data_consulta.strftime('%d/%m/%Y')}*\n\n"""
            
            for liturgia in liturgias:
                tipo_display = liturgia.get_LIT_TIPOLIT_display() if hasattr(liturgia, 'get_LIT_TIPOLIT_display') else liturgia.LIT_TIPOLIT
                resposta += f"*{tipo_display}*\n"
                if liturgia.LIT_TEXTO:
                    texto_limpo = liturgia.LIT_TEXTO[:500]  # Limitar tamanho
                    resposta += f"{texto_limpo}\n\n"
            
            resposta += "\nDigite *MENU* para voltar ao menu principal."
            return {'texto': resposta, 'tipo': 'texto'}
            
        except Exception as e:
            logger.error(f"Erro ao buscar liturgia: {e}")
            return {'texto': '❌ Erro ao buscar liturgia. Tente novamente.', 'tipo': 'texto'}
    
    def horarios_missa(self, telefone, nome, mensagem):
        """Consulta horários de missas"""
        try:
            paroquia = TBPAROQUIA.objects.first()
            if not paroquia:
                return {'texto': '❌ Informações da paróquia não encontradas.', 'tipo': 'texto'}
            
            horarios = paroquia.get_horarios_fixos()
            
            if not horarios:
                resposta = """⛪ *HORÁRIOS DE MISSAS*

Horários ainda não foram cadastrados.

Entre em contato com a secretaria para mais informações.
"""
                return {'texto': resposta, 'tipo': 'texto'}
            
            resposta = """⛪ *HORÁRIOS DE MISSAS*\n\n"""
            
            dias_semana = {
                'segunda': 'Segunda-feira',
                'terca': 'Terça-feira',
                'quarta': 'Quarta-feira',
                'quinta': 'Quinta-feira',
                'sexta': 'Sexta-feira',
                'sabado': 'Sábado',
                'domingo': 'Domingo',
            }
            
            for dia, horarios_dia in horarios.items():
                dia_display = dias_semana.get(dia, dia.capitalize())
                resposta += f"*{dia_display}*\n"
                for horario in horarios_dia:
                    resposta += f"  🕐 {horario}\n"
                resposta += "\n"
            
            resposta += "\nDigite *MENU* para voltar."
            return {'texto': resposta, 'tipo': 'texto'}
            
        except Exception as e:
            logger.error(f"Erro ao buscar horários: {e}")
            return {'texto': '❌ Erro ao buscar horários. Tente novamente.', 'tipo': 'texto'}
    
    def eventos_paroquia(self, telefone, nome, mensagem):
        """Lista eventos da paróquia"""
        try:
            # Buscar próximos eventos
            hoje = date.today()
            eventos = TBCELEBRACOES.objects.filter(
                CEL_data_celebracao__gte=hoje,
                CEL_status__in=['pendente', 'confirmada']
            ).order_by('CEL_data_celebracao', 'CEL_horario')[:10]
            
            if not eventos.exists():
                resposta = """📅 *EVENTOS DA PARÓQUIA*

Não há eventos agendados no momento.

Digite *MENU* para voltar.
"""
                return {'texto': resposta, 'tipo': 'texto'}
            
            resposta = """📅 *PRÓXIMOS EVENTOS*\n\n"""
            
            for evento in eventos:
                data_str = evento.CEL_data_celebracao.strftime('%d/%m/%Y')
                hora_str = evento.CEL_horario.strftime('%H:%M') if evento.CEL_horario else ''
                resposta += f"*{evento.CEL_tipo_celebracao}*\n"
                resposta += f"📅 {data_str}"
                if hora_str:
                    resposta += f" 🕐 {hora_str}"
                resposta += f"\n📍 {evento.CEL_local or 'Não informado'}\n\n"
            
            resposta += "\nDigite *MENU* para voltar."
            return {'texto': resposta, 'tipo': 'texto'}
            
        except Exception as e:
            logger.error(f"Erro ao buscar eventos: {e}")
            return {'texto': '❌ Erro ao buscar eventos. Tente novamente.', 'tipo': 'texto'}
    
    def pedido_oracao(self, telefone, nome, mensagem):
        """Processa pedido de oração"""
        resposta = """🙏 *PEDIDO DE ORAÇÃO*

Para fazer um pedido de oração, envie sua intenção.

Exemplo:
"Peço oração pela saúde da minha mãe"

Digite *MENU* para voltar.
"""
        return {'texto': resposta, 'tipo': 'texto', 'contexto': 'pedido_oracao'}
    
    def contato_paroquia(self, telefone, nome, mensagem):
        """Informações de contato da paróquia"""
        try:
            paroquia = TBPAROQUIA.objects.first()
            if not paroquia:
                return {'texto': '❌ Informações não encontradas.', 'tipo': 'texto'}
            
            resposta = """📞 *CONTATO DA PARÓQUIA*\n\n"""
            resposta += f"*{paroquia.PAR_nome_paroquia or 'Paróquia'}*\n\n"
            
            if paroquia.PAR_telefone:
                resposta += f"📱 Telefone: {paroquia.PAR_telefone}\n"
            if paroquia.PAR_email:
                resposta += f"📧 E-mail: {paroquia.PAR_email}\n"
            if paroquia.PAR_endereco:
                resposta += f"📍 {paroquia.PAR_endereco}"
                if paroquia.PAR_bairro:
                    resposta += f", {paroquia.PAR_bairro}"
                if paroquia.PAR_cidade:
                    resposta += f"\n{paroquia.PAR_cidade}"
                if paroquia.PAR_uf:
                    resposta += f"/{paroquia.PAR_uf}"
                if paroquia.PAR_cep:
                    resposta += f" - CEP: {paroquia.PAR_cep}"
                resposta += "\n"
            
            if paroquia.PAR_paroco:
                resposta += f"\n👤 Pároco: {paroquia.PAR_paroco}\n"
            
            resposta += "\nDigite *MENU* para voltar."
            return {'texto': resposta, 'tipo': 'texto'}
            
        except Exception as e:
            logger.error(f"Erro ao buscar contato: {e}")
            return {'texto': '❌ Erro ao buscar informações. Tente novamente.', 'tipo': 'texto'}
    
    def _extrair_data(self, texto):
        """Extrai data do texto (formato dd/mm/yyyy ou dd-mm-yyyy)"""
        padroes = [
            r'(\d{1,2})[/-](\d{1,2})[/-](\d{4})',
            r'(\d{4})[/-](\d{1,2})[/-](\d{1,2})',
        ]
        
        for padrao in padroes:
            match = re.search(padrao, texto)
            if match:
                grupos = match.groups()
                try:
                    if len(grupos[0]) == 4:  # Formato yyyy-mm-dd
                        return datetime.strptime(f"{grupos[0]}-{grupos[1]}-{grupos[2]}", '%Y-%m-%d').date()
                    else:  # Formato dd-mm-yyyy
                        return datetime.strptime(f"{grupos[2]}-{grupos[1]}-{grupos[0]}", '%Y-%m-%d').date()
                except ValueError:
                    continue
        
        return None


# Instância global do chatbot
chatbot = WhatsAppChatbot()


@csrf_exempt
@require_http_methods(["POST", "GET"])
def whatsapp_webhook(request):
    """
    Webhook para receber mensagens do WhatsApp
    Formato esperado (exemplo):
    {
        "message": {
            "from": "5518999999999",
            "text": "menu",
            "name": "João Silva"
        }
    }
    """
    try:
        if request.method == 'GET':
            # Verificação do webhook (algumas APIs requerem)
            verify_token = request.GET.get('verify_token')
            challenge = request.GET.get('challenge')
            
            # TODO: Implementar verificação de token
            if verify_token:
                return JsonResponse({'challenge': challenge} if challenge else {})
            
            return JsonResponse({'status': 'webhook_ready'})
        
        # Processar mensagem POST
        data = json.loads(request.body) if request.body else {}
        
        # Extrair dados da mensagem (ajustar conforme API do WhatsApp)
        mensagem_data = data.get('message', {}) or data.get('entry', [{}])[0].get('changes', [{}])[0].get('value', {}).get('messages', [{}])[0]
        
        telefone_remetente = mensagem_data.get('from') or mensagem_data.get('wa_id')
        mensagem_texto = mensagem_data.get('text', {}).get('body') if isinstance(mensagem_data.get('text'), dict) else mensagem_data.get('text', '')
        nome_remetente = mensagem_data.get('name') or mensagem_data.get('profile', {}).get('name')
        
        if not telefone_remetente or not mensagem_texto:
            logger.warning(f"Mensagem incompleta recebida: {data}")
            return JsonResponse({'status': 'error', 'message': 'Dados incompletos'}, status=400)
        
        # Processar mensagem
        resposta = chatbot.processar_mensagem(mensagem_texto, telefone_remetente, nome_remetente)
        
        # Formatar resposta para API do WhatsApp
        resposta_api = {
            'to': telefone_remetente,
            'type': resposta.get('tipo', 'text'),
            'text': {'body': resposta.get('texto', '')}
        }
        
        # Log da interação
        logger.info(f"WhatsApp - {telefone_remetente}: {mensagem_texto[:50]}...")
        
        return JsonResponse(resposta_api)
        
    except json.JSONDecodeError:
        logger.error("Erro ao decodificar JSON do webhook")
        return JsonResponse({'status': 'error', 'message': 'JSON inválido'}, status=400)
    except Exception as e:
        logger.error(f"Erro no webhook WhatsApp: {e}", exc_info=True)
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)


@csrf_exempt
@require_http_methods(["POST"])
def whatsapp_cadastro_dizimista(request):
    """
    Endpoint específico para cadastro de dizimista via WhatsApp
    Recebe dados do formulário de cadastro
    """
    try:
        data = json.loads(request.body)
        telefone = data.get('telefone')
        
        if not telefone:
            return JsonResponse({'status': 'error', 'message': 'Telefone é obrigatório'}, status=400)
        
        # Preparar dados para o form
        form_data = {
            'DIS_telefone': telefone,
            'DIS_nome': data.get('nome', ''),
            'DIS_email': data.get('email', ''),
            'DIS_data_nascimento': data.get('data_nascimento', ''),
            'DIS_sexo': data.get('sexo', ''),
            'DIS_cep': data.get('cep', ''),
            'DIS_endereco': data.get('endereco', ''),
            'DIS_numero': data.get('numero', ''),
            'DIS_complemento': data.get('complemento', ''),
            'DIS_bairro': data.get('bairro', ''),
            'DIS_cidade': data.get('cidade', ''),
            'DIS_estado': data.get('estado', ''),
            'DIS_cpf': data.get('cpf', ''),
            'DIS_valor': data.get('valor', ''),
        }
        
        # Validar com o form existente
        form = DizimistaPublicoForm(form_data)
        
        if form.is_valid():
            dizimista = form.save(commit=False)
            dizimista.DIS_status = False  # Pendente
            dizimista.save()
            
            resposta = f"""✅ *CADASTRO REALIZADO COM SUCESSO!*

Olá {dizimista.DIS_nome}, seu cadastro foi realizado!

📝 *Seus dados:*
• Telefone: {dizimista.DIS_telefone}
• Status: Pendente de confirmação

Em breve entraremos em contato para confirmar seus dados.

Digite *MENU* para voltar ao menu principal.
"""
            
            return JsonResponse({
                'status': 'success',
                'message': resposta,
                'dizimista_id': dizimista.pk
            })
        else:
            # Retornar erros de validação
            erros = {}
            for campo, erros_campo in form.errors.items():
                erros[campo] = erros_campo[0] if erros_campo else 'Erro de validação'
            
            resposta = "❌ *ERRO NO CADASTRO*\n\n"
            resposta += "Por favor, verifique os dados:\n\n"
            for campo, erro in erros.items():
                resposta += f"• {campo}: {erro}\n"
            
            return JsonResponse({
                'status': 'error',
                'message': resposta,
                'errors': erros
            }, status=400)
            
    except json.JSONDecodeError:
        return JsonResponse({'status': 'error', 'message': 'JSON inválido'}, status=400)
    except Exception as e:
        logger.error(f"Erro ao cadastrar dizimista via WhatsApp: {e}", exc_info=True)
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)

