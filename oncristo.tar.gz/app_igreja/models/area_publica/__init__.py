# Models da área pública
# Esta pasta contém os modelos específicos da área pública do sistema
