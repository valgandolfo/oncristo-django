# ==================== IMPORTAÇÕES DOS FORMULÁRIOS ====================
# Importações dos formulários organizados por área

# Formulários específicos agora importados diretamente nas views
# Quando necessário, use: from ...forms.area_admin.forms_paroquias import ParoquiaForm

# Formulários da área pública (se existirem)
# from .area_publica.forms_area_publica import *

# Formulários gerais (autenticação, etc.)
# Removido - usando formulários padrão do Django
