# 🚀 Comandos para Executar no Servidor

## ✅ Status Atual:
- ✅ Python 3.13.3 instalado
- ✅ Nginx instalado
- ❌ Gunicorn precisa instalar

---

## 📋 PASSO 1: Instalar Gunicorn e dependências

Execute no servidor:

```bash
# Atualizar sistema
apt update

# Instalar pip se não tiver
apt install -y python3-pip

# Instalar Gunicorn
pip3 install gunicorn

# Verificar se instalou
gunicorn --version
```

**Me diga o resultado!**

---

## 📋 PASSO 2: Verificar outras dependências

```bash
# Verificar se tem git
git --version

# Verificar se tem mysql-client (para testar banco)
mysql --version
```

---

## 📋 PASSO 3: Criar diretório do projeto

```bash
# Criar diretório
mkdir -p /home/oncristo
cd /home/oncristo
```

---

## 📋 PRÓXIMOS PASSOS (depois):

1. Transferir projeto do seu PC para o servidor
2. Criar ambiente virtual
3. Instalar dependências do projeto
4. Configurar .env_production
5. Aplicar migrações
6. Configurar Gunicorn
7. Configurar Nginx

---

## 🎯 EXECUTE AGORA:

```bash
apt update && apt install -y python3-pip && pip3 install gunicorn && gunicorn --version
```

