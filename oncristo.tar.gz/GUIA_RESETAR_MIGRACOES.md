# Guia: Resetar Migrações e Começar do Zero

## 🎯 Por que fazer isso?

Se você ainda **não publicou** o projeto e não tem dados importantes no banco de dados, é **altamente recomendado** resetar todas as migrações e começar com uma migração inicial limpa. Isso evita:

- ❌ Problemas com migrações conflitantes
- ❌ Dependências complexas entre migrações antigas
- ❌ Erros ao fazer deploy em produção
- ❌ Confusão com histórico de mudanças

## 📋 Pré-requisitos

- ✅ Projeto ainda não está em produção
- ✅ Não há dados importantes no banco de dados
- ✅ Você tem backup do código (Git, etc.)

## 🚀 Processo Automatizado

### Opção 1: Usar o Script Automatizado (Recomendado)

```bash
# Execute o script na raiz do projeto
./resetar_migracoes.sh
```

O script irá:
1. ✅ Fazer backup do banco atual (se existir)
2. ✅ Remover todas as migrações antigas
3. ✅ Deletar o banco de dados SQLite local
4. ✅ Criar uma nova migração inicial limpa
5. ✅ Aplicar a migração
6. ✅ Oferecer criar superusuário

### Opção 2: Processo Manual

Se preferir fazer manualmente:

```bash
# 1. Ativar ambiente virtual
source venv/bin/activate

# 2. Fazer backup do banco (opcional)
cp db.sqlite3 db_backup_$(date +%Y%m%d_%H%M%S).sqlite3

# 3. Deletar banco de dados
rm db.sqlite3

# 4. Remover todas as migrações (exceto __init__.py)
find app_igreja/migrations -type f -name "*.py" ! -name "__init__.py" -delete
rm -rf app_igreja/migrations/__pycache__

# 5. Criar nova migração inicial
python manage.py makemigrations app_igreja

# 6. Aplicar migração
python manage.py migrate

# 7. Criar superusuário (opcional)
python manage.py createsuperuser
```

## 🌐 Deploy na Digital Ocean

### Passo 1: Configurar Banco de Dados PostgreSQL

No arquivo `pro_igreja/settings.py`, configure o banco PostgreSQL:

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'seu_banco',
        'USER': 'seu_usuario',
        'PASSWORD': 'sua_senha',
        'HOST': 'seu_host_digitalocean',
        'PORT': '25060',  # Porta padrão Digital Ocean
    }
}
```

### Passo 2: Aplicar Migrações na Produção

```bash
# No servidor da Digital Ocean
python manage.py migrate
python manage.py createsuperuser
python manage.py collectstatic --noinput
```

### Passo 3: Verificar

```bash
# Verificar status das migrações
python manage.py showmigrations

# Deve mostrar apenas:
# app_igreja
#  [X] 0001_initial
```

## ✅ Vantagens de Começar do Zero

1. **Migração Única**: Uma única migração inicial (`0001_initial.py`) contém toda a estrutura
2. **Sem Conflitos**: Não há dependências complexas entre migrações
3. **Deploy Limpo**: Deploy em produção será muito mais simples
4. **Manutenção Fácil**: Futuras mudanças serão mais fáceis de gerenciar
5. **Performance**: Migrações aplicam mais rápido

## ⚠️ Importante

- **NUNCA** faça isso se já tiver dados importantes em produção
- **SEMPRE** faça backup antes de executar
- **VERIFIQUE** se não há outros apps Django com migrações
- **TESTE** localmente antes de fazer deploy

## 🔄 Se Precisar Voltar

Se você fez backup do banco:

```bash
# Restaurar banco de dados
cp db_backup_YYYYMMDD_HHMMSS.sqlite3 db.sqlite3

# Restaurar migrações (se tiver backup)
git checkout app_igreja/migrations/
```

## 📝 Estrutura Final Esperada

Após resetar, você terá:

```
app_igreja/migrations/
├── __init__.py
└── 0001_initial.py  # Única migração com toda a estrutura
```

## 🎉 Pronto!

Agora você tem um projeto limpo, sem histórico de migrações complexas, pronto para ser publicado na Digital Ocean!

