# 🔧 Instalar Gunicorn Corretamente

## Problema: Gunicorn não encontrado após instalação

Isso acontece porque o pip pode ter instalado em um local que não está no PATH.

---

## ✅ SOLUÇÃO: Instalar com pip3 explicitamente

Execute no servidor:

```bash
# Atualizar sistema
apt update

# Instalar pip3 se não tiver
apt install -y python3-pip

# Instalar Gunicorn globalmente
pip3 install gunicorn

# Verificar onde foi instalado
pip3 show gunicorn

# Testar se funciona
python3 -m gunicorn --version
```

---

## 🔍 Se ainda não funcionar, instalar como usuário root:

```bash
# Instalar com --user
pip3 install --user gunicorn

# Adicionar ao PATH (temporário)
export PATH=$PATH:~/.local/bin

# Testar
gunicorn --version
```

---

## 🎯 OU: Instalar via apt (mais simples)

```bash
apt install -y gunicorn
gunicorn --version
```

---

## 💡 RECOMENDAÇÃO:

Como vamos usar ambiente virtual, podemos instalar o Gunicorn dentro do venv depois. Mas vamos testar uma das opções acima primeiro!

