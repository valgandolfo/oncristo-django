#!/bin/bash
# Script de Deploy para Digital Ocean
# Uso: ./deploy.sh

set -e  # Parar em caso de erro

echo "🚀 Iniciando deploy..."

# Cores para output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# Verificar se está no diretório correto
if [ ! -f "manage.py" ]; then
    echo -e "${RED}❌ Você não está no diretório do projeto Django!${NC}"
    exit 1
fi

# Verificar se ambiente virtual existe
if [ ! -d "venv" ]; then
    echo -e "${YELLOW}⚠️  Ambiente virtual não encontrado!${NC}"
    exit 1
fi

# Ativar ambiente virtual
echo -e "${BLUE}ℹ️  Ativando ambiente virtual...${NC}"
source venv/bin/activate

# Definir ambiente de produção
export DJANGO_ENV=production

# Verificar se .env_production existe
if [ ! -f ".env_production" ]; then
    echo -e "${YELLOW}⚠️  Arquivo .env_production não encontrado!${NC}"
    echo "Crie o arquivo .env_production antes de fazer deploy."
    exit 1
fi

# Carregar variáveis de ambiente
export $(cat .env_production | grep -v '^#' | xargs)

# Verificar se Django está instalado
if ! python -c "import django" 2>/dev/null; then
    echo -e "${YELLOW}⚠️  Django não encontrado!${NC}"
    echo "Instalando dependências..."
    pip install -r requirements.txt
fi

echo -e "${GREEN}✅ Ambiente configurado!${NC}"
echo ""

# 1. Verificar configurações
echo -e "${BLUE}1. Verificando configurações...${NC}"
python manage.py check --deploy
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Configurações OK!${NC}"
else
    echo -e "${RED}❌ Erro nas configurações!${NC}"
    exit 1
fi

# 2. Executar migrações
echo ""
echo -e "${BLUE}2. Executando migrações...${NC}"
python manage.py migrate --noinput
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Migrações aplicadas!${NC}"
else
    echo -e "${RED}❌ Erro nas migrações!${NC}"
    exit 1
fi

# 3. Coletar arquivos estáticos
echo ""
echo -e "${BLUE}3. Coletando arquivos estáticos...${NC}"
python manage.py collectstatic --noinput
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Arquivos estáticos coletados!${NC}"
else
    echo -e "${YELLOW}⚠️  Aviso ao coletar arquivos estáticos.${NC}"
fi

# 4. Reiniciar Gunicorn (se estiver rodando)
echo ""
if systemctl is-active --quiet gunicorn; then
    echo -e "${BLUE}4. Reiniciando Gunicorn...${NC}"
    sudo systemctl restart gunicorn
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ Gunicorn reiniciado!${NC}"
    else
        echo -e "${YELLOW}⚠️  Erro ao reiniciar Gunicorn.${NC}"
    fi
else
    echo -e "${YELLOW}⚠️  Gunicorn não está rodando.${NC}"
fi

# 5. Testar Nginx
echo ""
if command -v nginx &> /dev/null; then
    echo -e "${BLUE}5. Testando configuração Nginx...${NC}"
    sudo nginx -t
    if [ $? -eq 0 ]; then
        sudo systemctl reload nginx
        echo -e "${GREEN}✅ Nginx recarregado!${NC}"
    else
        echo -e "${RED}❌ Erro na configuração do Nginx!${NC}"
    fi
fi

echo ""
echo -e "${GREEN}🎉 Deploy concluído com sucesso!${NC}"
echo ""
echo -e "${BLUE}📋 Próximos passos:${NC}"
echo "  1. Verificar logs: sudo journalctl -u gunicorn -f"
echo "  2. Testar aplicação: https://seudominio.com.br"
echo "  3. Verificar serviços: sudo systemctl status gunicorn"

