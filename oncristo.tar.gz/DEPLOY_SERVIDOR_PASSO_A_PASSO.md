# 🚀 Deploy no Servidor - Passo a Passo

## ✅ Você está conectado! Agora vamos:

---

## 📋 PASSO 1: Verificar o que já está instalado

Execute no servidor:

```bash
# Verificar Python
python3 --version

# Verificar pip
pip3 --version

# Verificar Gunicorn (você disse que já tem)
gunicorn --version

# Verificar Nginx
nginx -v
```

**Me diga o resultado de cada comando!**

---

## 📋 PASSO 2: Atualizar sistema (se necessário)

```bash
apt update
apt upgrade -y
```

---

## 📋 PASSO 3: Instalar dependências que faltam

```bash
# Instalar Python e ferramentas
apt install -y python3.12 python3.12-venv python3-pip git

# Instalar cliente MySQL (para testar conexão)
apt install -y mysql-client
```

---

## 📋 PASSO 4: Criar usuário para o projeto (recomendado)

```bash
# Criar usuário
adduser --disabled-password --gecos "" oncristo

# Dar permissões sudo
usermod -aG sudo oncristo

# Mudar para o usuário
su - oncristo
```

---

## 📋 PASSO 5: Transferir projeto para o servidor

**Do seu computador LOCAL, execute:**

```bash
# Compactar o projeto (sem venv e arquivos desnecessários)
cd /home/joaonote/oncristo.local
tar --exclude='venv' --exclude='__pycache__' --exclude='*.pyc' --exclude='.git' -czf oncristo.tar.gz .

# Transferir para o servidor
scp oncristo.tar.gz root@137.184.116.197:/root/
```

**Depois, no servidor:**

```bash
# Descompactar
cd /home/oncristo
tar -xzf /root/oncristo.tar.gz
```

---

## 📋 PASSO 6: Configurar ambiente virtual

```bash
cd /home/oncristo/oncristo.local
python3.12 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

---

## 📋 PASSO 7: Configurar .env_production

```bash
# Copiar o arquivo .env_production que criamos
nano .env_production
```

**Verificar se está com as credenciais corretas do banco!**

---

## 📋 PASSO 8: Aplicar migrações

```bash
export DJANGO_ENV=production
python manage.py migrate
```

---

## 📋 PASSO 9: Coletar arquivos estáticos

```bash
python manage.py collectstatic --noinput
```

---

## 📋 PASSO 10: Configurar Gunicorn

Já que você disse que tem Gunicorn, vamos verificar e configurar!

---

## 📋 PASSO 11: Configurar Nginx

Vamos configurar o Nginx para servir o projeto.

---

## 📋 PASSO 12: Testar

Acessar: https://oncristo.com.br

---

## 🎯 VAMOS COMEÇAR PELO PASSO 1!

Execute no servidor e me diga o resultado:

```bash
python3 --version
gunicorn --version
nginx -v
```

