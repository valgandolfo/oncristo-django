# 📋 Resumo Rápido - Deploy OnCristo

## ✅ O que você já tem:
- ✅ Droplet: `projeto-on-cristo` (137.184.116.197)
- ✅ Domínio: `oncristo.com.br` (DNS configurado)
- ✅ Banco MySQL no Digital Ocean (precisa criar novo)
- ✅ Gunicorn já instalado
- ✅ Webhook rodando em subdomínio

---

## 🎯 Próximos Passos (Amanhã):

### 1️⃣ **Criar Novo Banco MySQL**
   - No painel Digital Ocean → Databases → Create
   - Anotar: Host, Port, User, Password
   - Criar database: `oncristo_db`

### 2️⃣ **Transferir Projeto para Servidor**
   ```bash
   # Do seu computador local:
   scp -r /home/joaonote/oncristo.local oncristo@137.184.116.197:/home/oncristo/
   ```

### 3️⃣ **Configurar .env_production no Servidor**
   - Copiar `.env_production.example` para `.env_production`
   - Preencher com credenciais do banco MySQL
   - Configurar `ALLOWED_HOSTS=oncristo.com.br,www.oncristo.com.br,137.184.116.197`

### 4️⃣ **Executar Deploy**
   ```bash
   # No servidor:
   cd /home/oncristo/oncristo.local
   ./deploy_producao.sh
   ```

### 5️⃣ **Configurar Gunicorn e Nginx**
   - Seguir instruções em `DEPLOY_DIGITAL_OCEAN.md`

---

## 📁 Arquivos Criados:

1. **`DEPLOY_DIGITAL_OCEAN.md`** - Guia completo passo a passo
2. **`deploy_producao.sh`** - Script automatizado de deploy
3. **`setup_banco_mysql.sh`** - Script para configurar banco
4. **`.env_production.example`** - Template atualizado com suas informações

---

## 🔑 Informações Importantes:

- **IP Público**: 137.184.116.197
- **IP Privado**: 10.124.0.3
- **Domínio**: oncristo.com.br
- **Banco**: MySQL 8 (Digital Ocean)
- **Porta MySQL**: 25060 (padrão Digital Ocean)

---

## ⚡ Comandos Rápidos:

```bash
# Conectar ao servidor
ssh root@137.184.116.197

# Ver status do Gunicorn
sudo systemctl status gunicorn_oncristo

# Ver logs
sudo journalctl -u gunicorn_oncristo -f

# Reiniciar serviços
sudo systemctl restart gunicorn_oncristo
sudo systemctl restart nginx
```

---

Boa sorte com o deploy! 🚀

