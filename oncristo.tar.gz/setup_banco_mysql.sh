#!/bin/bash

# ============================================
# Script para Configurar Banco MySQL no Digital Ocean
# ============================================

set -e

echo "🔧 Configurando Banco MySQL para OnCristo"
echo "=========================================="

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Funções auxiliares
print_info() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

# Verificar se está no servidor de produção
if [ -z "$DB_HOST" ]; then
    print_warning "Variáveis de ambiente não configuradas"
    print_info "Este script deve ser executado no servidor de produção"
    print_info "Ou configure as variáveis: DB_HOST, DB_USER, DB_PASSWORD, DB_NAME"
    exit 1
fi

# Verificar se mysql-client está instalado
if ! command -v mysql &> /dev/null; then
    print_info "Instalando mysql-client..."
    sudo apt update
    sudo apt install -y mysql-client
fi

# Testar conexão
print_info "Testando conexão com o banco de dados..."
mysql -h "$DB_HOST" \
      -u "$DB_USER" \
      -p"$DB_PASSWORD" \
      -P "${DB_PORT:-25060}" \
      -e "SELECT 1;" 2>/dev/null && print_info "Conexão OK!" || {
    print_error "Erro ao conectar ao banco de dados"
    exit 1
}

# Criar banco de dados se não existir
print_info "Verificando se o banco '$DB_NAME' existe..."
mysql -h "$DB_HOST" \
      -u "$DB_USER" \
      -p"$DB_PASSWORD" \
      -P "${DB_PORT:-25060}" \
      -e "CREATE DATABASE IF NOT EXISTS \`$DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>/dev/null

if [ $? -eq 0 ]; then
    print_info "Banco de dados '$DB_NAME' criado/verificado com sucesso!"
else
    print_error "Erro ao criar banco de dados"
    exit 1
fi

# Verificar charset
print_info "Verificando charset do banco..."
mysql -h "$DB_HOST" \
      -u "$DB_USER" \
      -p"$DB_PASSWORD" \
      -P "${DB_PORT:-25060}" \
      "$DB_NAME" \
      -e "SELECT DEFAULT_CHARACTER_SET_NAME, DEFAULT_COLLATION_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = '$DB_NAME';"

print_info "✅ Banco de dados configurado com sucesso!"
print_info "Agora você pode executar: python manage.py migrate"

