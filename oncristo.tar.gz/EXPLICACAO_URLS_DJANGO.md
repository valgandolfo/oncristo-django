# 📚 Explicação: Sistema de URLs no Django

## 🎯 Decisão Final: Duas Abordagens para Contextos Diferentes

### ✅ **JavaScript Direto** → `home.html` (Área Pública)
### ✅ **Django URLs** → `admin_area.html` (Área Administrativa)

---

## 🔄 Dois Métodos Diferentes

### 1️⃣ **Método JavaScript (home.html) - Área Pública**

```
home.html (linha 72)
    ↓
onclick="abrirAniversariantes()"
    ↓
JavaScript (linha 218-221)
    ↓
window.location.href = '/app_igreja/aniversariantes-mes/'
    ↓
URLs.py (linha 245)
    ↓
path('aniversariantes-mes/', aniversariantes_mes, name='aniversariantes_mes')
    ↓
views_aniversariantes.py (linha 11)
    ↓
def aniversariantes_mes(request):
```

**Características:**
- ✅ Simples e direto
- ✅ Funciona bem para área pública
- ✅ URLs fixas sem parâmetros
- ❌ Não integra com `reverse()` das views
- ❌ Não suporta URLs dinâmicas com parâmetros

### 2️⃣ **Método Django URLs (admin_area.html) - Área Admin**

```
admin_area.html (linha 313-317)
    ↓
{% url 'app_igreja:listar_colaboradores' %}
    ↓
URLs.py (linha 79)
    ↓
path('admin-area/colaboradores/', listar_colaboradores, name='listar_colaboradores')
    ↓
views_colaboradores.py (linha 37)
    ↓
def listar_colaboradores(request):
    # Usa reverse() para redirecionamentos
    reverse('app_igreja:listar_colaboradores')
```

**Características:**
- ✅ Integra perfeitamente com `reverse()` e `redirect()`
- ✅ Suporta URLs dinâmicas com parâmetros
- ✅ Funciona com formulários Master-Detail
- ✅ Manutenção centralizada (só altera em `urls.py`)
- ✅ Padrão Django recomendado

---

## 📍 Onde Cada Coisa Está Definida

### **1. URLs (app_igreja/urls.py)**

```python
# Linha 8: Importa a view
from .views.admin_area.views_colaboradores import listar_colaboradores

# Linha 79: Define a URL e conecta com a view
path('admin-area/colaboradores/', listar_colaboradores, name='listar_colaboradores'),
```

**Estrutura:**
- `'admin-area/colaboradores/'` = URL que aparece no navegador
- `listar_colaboradores` = Função Python (view) que será executada
- `name='listar_colaboradores'` = Nome usado no template com `{% url %}`

### **2. Views (app_igreja/views/admin_area/views_colaboradores.py)**

```python
# Linha 37: Função que processa a requisição
def listar_colaboradores(request):
    """
    Lista colaboradores com busca e paginação
    """
    # Lógica aqui...
    # Usa reverse() para redirecionamentos
    next_url = reverse('app_igreja:listar_colaboradores')
    return render(request, 'admin_area/tpl_colaboradores.html', context)
```

### **3. Template (templates/admin_area/admin_area.html)**

```django
<!-- Linha 313-317: Gera a URL automaticamente -->
<a href="{% url 'app_igreja:listar_colaboradores' %}" ...>
    <span class="fw-bold">Colaboradores</span>
</a>
```

---

## 🎯 Por Que Django URLs no admin_area.html?

### **1. Views Usam `reverse()` e `redirect()`**

Todas as views administrativas usam nomes de URLs:

```python
# Exemplo: views_banners.py
reverse('app_igreja:listar_banners')
redirect('app_igreja:listar_banners')
```

Se usássemos JavaScript fixo, essas funções quebrariam!

### **2. URLs com Parâmetros Dinâmicos**

Muitas URLs têm parâmetros:

```python
# urls.py
path('eventos-master-detail/<int:pk>/', ...)
path('banners/<int:banner_id>/editar/', ...)
path('escala-mensal/gerar/<int:mes>/<int:ano>/', ...)
```

Com JavaScript fixo, não há como passar parâmetros dinamicamente!

### **3. Formulários Master-Detail**

Eventos, Modelos, Planos precisam de URLs dinâmicas:

```django
<!-- No template de eventos -->
{% url 'app_igreja:eventos_master_detail_view' pk=evento.id %}
{% url 'app_igreja:eventos_master_detail_itens' pk=evento.id %}
```

JavaScript fixo não consegue gerar essas URLs!

### **4. Manutenibilidade**

- **Com Django URLs**: Altera só em `urls.py`
- **Com JavaScript**: Precisaria alterar em vários lugares (template + JavaScript)

---

## 🔧 Como Adicionar um Novo Link

### **Para admin_area.html (Django URLs)**

#### **Passo 1: Criar a View**
```python
# app_igreja/views/admin_area/views_exemplo.py
def minha_view(request):
    return render(request, 'admin_area/tpl_exemplo.html', {})
```

#### **Passo 2: Adicionar URL**
```python
# app_igreja/urls.py
from .views.admin_area.views_exemplo import minha_view

path('admin-area/exemplo/', minha_view, name='minha_view'),
```

#### **Passo 3: Usar no Template**
```django
<!-- templates/admin_area/admin_area.html -->
<a href="{% url 'app_igreja:minha_view' %}">
    Meu Link
</a>
```

### **Para home.html (JavaScript)**

#### **Passo 1: Adicionar URL**
```python
# app_igreja/urls.py
path('minha-pagina/', minha_view_publica, name='minha_pagina'),
```

#### **Passo 2: Criar Função JavaScript**
```javascript
// templates/home.html
function abrirMinhaPagina() {
    window.location.href = '/app_igreja/minha-pagina/';
}
```

#### **Passo 3: Usar no Template**
```django
<!-- templates/home.html -->
<a href="#" onclick="abrirMinhaPagina()">
    Minha Página
</a>
```

---

## 📊 Comparação Detalhada

| Aspecto | JavaScript (home.html) | Django URLs (admin_area.html) |
|---------|----------------------|------------------------------|
| **Localização** | Template + JavaScript | URLs.py + Views |
| **Manutenção** | Precisa alterar em 2 lugares | Altera só em 1 lugar (urls.py) |
| **Padrão Django** | ❌ Não é padrão | ✅ Padrão Django |
| **Flexibilidade** | URL fixa no código | URL dinâmica |
| **Parâmetros** | ❌ Não suporta | ✅ Suporta `<int:pk>` |
| **Integração** | ❌ Não integra com views | ✅ Integra com `reverse()` |
| **Master-Detail** | ❌ Não funciona | ✅ Funciona perfeitamente |
| **Uso Ideal** | Área pública simples | Área admin complexa |

---

## 🔍 Exemplos Práticos

### **Exemplo 1: URL Simples (Ambos Funcionam)**

**JavaScript:**
```javascript
function abrirColaboradores() {
    window.location.href = '/app_igreja/admin-area/colaboradores/';
}
```

**Django URLs:**
```django
<a href="{% url 'app_igreja:listar_colaboradores' %}">
```

### **Exemplo 2: URL com Parâmetro (Só Django URLs Funciona)**

**JavaScript:**
```javascript
// ❌ NÃO FUNCIONA - Não consegue passar parâmetro dinamicamente
function abrirEvento(id) {
    window.location.href = '/app_igreja/admin-area/eventos-master-detail/' + id + '/';
}
```

**Django URLs:**
```django
<!-- ✅ FUNCIONA - Gera URL dinamicamente -->
<a href="{% url 'app_igreja:eventos_master_detail_view' pk=evento.id %}">
```

### **Exemplo 3: Redirecionamento na View (Só Django URLs Funciona)**

**Na View:**
```python
# ✅ FUNCIONA com Django URLs
def criar_banner(request):
    if form.is_valid():
        form.save()
        return redirect('app_igreja:listar_banners')  # Usa nome da URL
```

**Com JavaScript fixo:**
```python
# ❌ NÃO FUNCIONA - Precisaria hardcodar a URL
return redirect('/app_igreja/admin-area/banners/')  # URL fixa
```

---

## ✅ Decisão Final

### **home.html → JavaScript Direto**
- ✅ Área pública simples
- ✅ URLs sem parâmetros
- ✅ Não precisa integrar com `reverse()`
- ✅ Mais simples para área pública

### **admin_area.html → Django URLs**
- ✅ Área administrativa complexa
- ✅ URLs com parâmetros dinâmicos
- ✅ Integra com `reverse()` e `redirect()`
- ✅ Funciona com Master-Detail
- ✅ Padrão Django recomendado

---

## 📝 Resumo

1. **URLs são definidas em `urls.py`** com `path()` e `name=`
2. **Views usam `reverse()` e `redirect()`** com nomes de URLs
3. **Templates usam `{% url %}`** para gerar URLs dinamicamente
4. **JavaScript fixo** funciona para casos simples, mas não para casos complexos
5. **Django URLs** é a melhor opção para área administrativa

---

## 🎓 Conclusão

O sistema está configurado corretamente:
- **home.html**: JavaScript direto (área pública simples)
- **admin_area.html**: Django URLs (área admin complexa)

Cada abordagem no contexto certo! 🎯

