#!/usr/bin/env python3
"""
Debug específico para upload S3
"""

import os
import sys
import django
from django.conf import settings

# Configurar Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'pro_igreja.settings')
django.setup()

def test_s3_config():
    print("🔍 DEBUG CONFIGURAÇÕES S3")
    print("=" * 50)
    
    # Verificar se as configurações estão sendo carregadas
    print("📋 CONFIGURAÇÕES CARREGADAS:")
    print(f"   - DEFAULT_FILE_STORAGE: {getattr(settings, 'DEFAULT_FILE_STORAGE', 'NÃO DEFINIDO')}")
    print(f"   - AWS_ACCESS_KEY_ID: {getattr(settings, 'AWS_ACCESS_KEY_ID', 'NÃO DEFINIDO')}")
    print(f"   - AWS_SECRET_ACCESS_KEY: {'✅ DEFINIDO' if getattr(settings, 'AWS_SECRET_ACCESS_KEY', None) else '❌ NÃO DEFINIDO'}")
    print(f"   - AWS_STORAGE_BUCKET_NAME: {getattr(settings, 'AWS_STORAGE_BUCKET_NAME', 'NÃO DEFINIDO')}")
    print(f"   - AWS_S3_REGION_NAME: {getattr(settings, 'AWS_S3_REGION_NAME', 'NÃO DEFINIDO')}")
    print(f"   - AWS_DEFAULT_ACL: {getattr(settings, 'AWS_DEFAULT_ACL', 'NÃO DEFINIDO')}")
    
    # Verificar se django-storages está instalado
    try:
        import storages
        print(f"\n✅ django-storages instalado: {storages.__version__}")
    except ImportError:
        print(f"\n❌ django-storages NÃO instalado!")
        return
    
    # Verificar se boto3 está instalado
    try:
        import boto3
        print(f"✅ boto3 instalado: {boto3.__version__}")
    except ImportError:
        print(f"❌ boto3 NÃO instalado!")
        return
    
    # Testar conexão S3
    print(f"\n☁️ TESTANDO CONEXÃO S3:")
    try:
        s3_client = boto3.client(
            's3',
            aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
            region_name=settings.AWS_S3_REGION_NAME
        )
        
        # Tentar listar objetos do bucket
        response = s3_client.list_objects_v2(Bucket=settings.AWS_STORAGE_BUCKET_NAME, MaxKeys=1)
        print(f"✅ Conexão S3 OK! Bucket: {settings.AWS_STORAGE_BUCKET_NAME}")
        
    except Exception as e:
        print(f"❌ Erro na conexão S3: {e}")
        return
    
    # Testar upload direto
    print(f"\n📤 TESTANDO UPLOAD DIRETO:")
    try:
        from django.core.files.storage import default_storage
        from django.core.files.base import ContentFile
        
        # Criar arquivo de teste
        test_content = b"teste de upload s3"
        test_file = ContentFile(test_content, name="test_upload.txt")
        
        # Fazer upload
        file_path = default_storage.save("test_upload.txt", test_file)
        print(f"✅ Upload realizado: {file_path}")
        
        # Verificar se o arquivo existe
        if default_storage.exists(file_path):
            print(f"✅ Arquivo confirmado no S3: {file_path}")
            # Obter URL
            url = default_storage.url(file_path)
            print(f"✅ URL do arquivo: {url}")
        else:
            print(f"❌ Arquivo não encontrado no S3")
            
    except Exception as e:
        print(f"❌ Erro no upload: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_s3_config()
