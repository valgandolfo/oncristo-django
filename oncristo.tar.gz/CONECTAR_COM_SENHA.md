# 🔐 Conectar ao Digital Ocean com Senha

## 📋 Passo 1: Verificar Senha do Root

Você tem duas opções:

### Opção A: Senha que você configurou ao criar o droplet
- Se você criou o droplet e definiu uma senha, use essa

### Opção B: Resetar Senha no Digital Ocean

1. Acesse: https://cloud.digitalocean.com/droplets
2. Clique no seu droplet: **projeto-on-cristo**
3. Clique no menu **"..."** (três pontos) no canto superior direito
4. Selecione **"Reset Root Password"**
5. Aguarde alguns minutos
6. A senha será enviada por **email** ou aparecerá na tela

---

## 📋 Passo 2: Conectar via SSH com Senha

Execute no seu terminal:

```bash
ssh root@137.184.116.197
```

**Quando pedir senha:**
- Digite a senha (não aparece enquanto digita - é normal!)
- Pressione Enter

**Se aparecer "Are you sure you want to continue connecting (yes/no)?"**
- Digite `yes` e pressione Enter

---

## 📋 Passo 3: Verificar se Conectou

Depois de entrar, você deve ver algo como:

```
root@ubuntu-s-1vcpu-512mb-10gb-sfo3-01:~#
```

**Se aparecer isso, você está conectado!** ✅

---

## 🔧 Passo 4: Habilitar Acesso por Senha (se não funcionar)

Se o servidor estiver configurado apenas para chaves SSH, você pode habilitar senha:

1. Acesse o **Console do Droplet** no painel Digital Ocean:
   - Vá em **"Access"** → **"Launch Droplet Console"**
   - Isso abre um terminal no navegador

2. No console, execute:

```bash
# Editar configuração SSH
nano /etc/ssh/sshd_config

# Procurar a linha:
# PasswordAuthentication no

# Mudar para:
PasswordAuthentication yes

# Salvar (Ctrl+O, Enter, Ctrl+X)

# Reiniciar SSH
systemctl restart sshd
```

---

## ✅ Testar Conexão

Depois de configurar, teste:

```bash
ssh root@137.184.116.197
```

Digite a senha quando pedir.

---

## 💡 Dica: Usar Console do Digital Ocean

Se tiver dificuldade com SSH, você pode usar o console web:

1. No painel Digital Ocean → Seu droplet
2. Clique em **"Access"** → **"Launch Droplet Console"**
3. Isso abre um terminal no navegador (não precisa de SSH!)

---

## 🆘 Problemas?

**"Permission denied"**
- Verifique se a senha está correta
- Tente resetar a senha no painel Digital Ocean

**"Connection refused"**
- Verifique se o droplet está rodando
- Verifique o firewall

**Não consegue conectar**
- Use o Console Web do Digital Ocean como alternativa

