# 🚀 Deploy OnCristo - Passo a Passo

## ✅ PASSO 1: CONCLUÍDO - Configurar .env_production

**O que foi feito:**
- ✅ Arquivo `.env_production` criado com suas credenciais do banco
- ✅ SECRET_KEY gerada automaticamente
- ✅ Configuração de SSL para MySQL adicionada no `settings.py`

**Arquivos criados:**
- `.env_production` - Configurações de produção
- `testar_conexao_banco.py` - Script para testar conexão

---

## 🎯 PASSO 2: TESTAR CONEXÃO COM O BANCO (AGORA)

Execute este comando para testar se a conexão está funcionando:

```bash
cd /home/joaonote/oncristo.local
source venv/bin/activate
export DJANGO_ENV=production
python testar_conexao_banco.py
```

**O que esperar:**
- ✅ Se aparecer "Conexão com o banco de dados estabelecida com sucesso!" = Tudo OK!
- ❌ Se aparecer erro = Vamos corrigir juntos

---

## 📋 PASSO 3: APLICAR MIGRAÇÕES (DEPOIS DO TESTE)

Depois que a conexão estiver OK, vamos criar as tabelas no banco:

```bash
cd /home/joaonote/oncristo.local
source venv/bin/activate
export DJANGO_ENV=production
python manage.py migrate
```

**O que isso faz:**
- Cria todas as tabelas do projeto no banco MySQL
- Aplica todas as migrações do Django

---

## 📝 PASSO 4: CRIAR SUPERUSUÁRIO (OPCIONAL)

Para acessar o painel admin:

```bash
python manage.py createsuperuser
```

---

## 🔄 PRÓXIMOS PASSOS (DEPOIS)

1. Transferir projeto para o servidor Digital Ocean
2. Configurar Gunicorn
3. Configurar Nginx
4. Configurar SSL (Let's Encrypt)

---

## ⚠️ IMPORTANTE

- O arquivo `.env_production` contém senhas! **NÃO** commite no Git
- Mantenha este arquivo seguro e privado
- Use apenas no servidor de produção

---

## 🆘 SE DER ERRO

Me mostre a mensagem de erro completa que eu te ajudo a resolver!

