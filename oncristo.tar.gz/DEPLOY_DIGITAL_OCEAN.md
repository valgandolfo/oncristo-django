# 🚀 Deploy Digital Ocean - Projeto OnCristo

## 📋 Informações do Servidor

- **Domínio**: https://oncristo.com.br
- **Droplet**: projeto-on-cristo
- **IP Público**: 137.184.116.197
- **IP Privado**: 10.124.0.3 (10.48.0.6)
- **Sistema**: Ubuntu 25.04
- **Banco de Dados**: MySQL 8 (Digital Ocean Managed Database)
- **Região**: SFO3

---

## 🔧 Passo 1: Criar Novo Banco de Dados MySQL

### No Painel Digital Ocean:

1. Acesse **Databases** → **Create Database Cluster**
2. Escolha:
   - **Engine**: MySQL 8
   - **Plan**: 1 GB RAM / 1 vCPU / 10 GiB Disk
   - **Region**: SFO3
   - **Database Name**: `oncristo_db` (ou o nome que preferir)
3. Anote as credenciais:
   - **Host**: `db-mysql-sfo3-XXXXX.db.ondigitalocean.com`
   - **Port**: `25060` (geralmente)
   - **User**: `doadmin` (padrão)
   - **Password**: (será gerada)
   - **Database**: `defaultdb` (inicial) ou crie um novo

### Criar banco específico (via terminal ou painel):

```sql
CREATE DATABASE oncristo_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

---

## 📝 Passo 2: Configurar .env_production

No servidor, crie o arquivo `.env_production`:

```bash
# ============================================
# CONFIGURAÇÕES DE PRODUÇÃO - ONCRISTO
# ============================================

# Django
SECRET_KEY=GERAR_UMA_CHAVE_SECRETA_FORTE_AQUI
DEBUG=False
ALLOWED_HOSTS=oncristo.com.br,www.oncristo.com.br,137.184.116.197

# Banco de Dados MySQL
DB_ENGINE=django.db.backends.mysql
DB_NAME=oncristo_db
DB_USER=doadmin
DB_PASSWORD=SUA_SENHA_DO_BANCO
DB_HOST=db-mysql-sfo3-XXXXX.db.ondigitalocean.com
DB_PORT=25060

# AWS S3 (para mídia)
AWS_ACCESS_KEY_ID=sua_access_key_aws
AWS_SECRET_ACCESS_KEY=sua_secret_key_aws
AWS_STORAGE_BUCKET_NAME=nome_do_bucket_s3
AWS_S3_REGION_NAME=us-east-1

# Email (opcional)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=seu_email@gmail.com
EMAIL_HOST_PASSWORD=senha_app_gmail

# Ambiente
DJANGO_ENV=production
```

---

## 🖥️ Passo 3: Configurar Servidor

### 3.1 Conectar ao servidor:

```bash
ssh root@137.184.116.197
```

### 3.2 Atualizar sistema:

```bash
apt update && apt upgrade -y
```

### 3.3 Instalar dependências:

```bash
apt install -y python3.12 python3.12-venv python3-pip nginx mysql-client git
```

### 3.4 Criar usuário para o projeto:

```bash
adduser --disabled-password --gecos "" oncristo
usermod -aG sudo oncristo
su - oncristo
```

### 3.5 Clonar/Transferir projeto:

```bash
# Opção 1: Se tiver repositório Git
git clone SEU_REPOSITORIO /home/oncristo/oncristo.local

# Opção 2: Transferir via SCP (do seu computador local)
# scp -r /home/joaonote/oncristo.local oncristo@137.184.116.197:/home/oncristo/
```

---

## 🐍 Passo 4: Configurar Python e Dependências

```bash
cd /home/oncristo/oncristo.local

# Criar ambiente virtual
python3.12 -m venv venv
source venv/bin/activate

# Instalar dependências
pip install --upgrade pip
pip install -r requirements.txt
```

---

## 🗄️ Passo 5: Configurar Banco de Dados

### 5.1 Testar conexão:

```bash
mysql -h db-mysql-sfo3-XXXXX.db.ondigitalocean.com \
      -u doadmin \
      -p \
      -P 25060 \
      oncristo_db
```

### 5.2 Aplicar migrações:

```bash
cd /home/oncristo/oncristo.local
source venv/bin/activate
export DJANGO_ENV=production

# Aplicar migrações
python manage.py migrate

# Criar superusuário (se necessário)
python manage.py createsuperuser
```

---

## 📦 Passo 6: Configurar Arquivos Estáticos

```bash
# Coletar arquivos estáticos
python manage.py collectstatic --noinput
```

---

## 🔧 Passo 7: Configurar Gunicorn

### 7.1 Criar arquivo de serviço:

```bash
sudo nano /etc/systemd/system/gunicorn_oncristo.service
```

Conteúdo:

```ini
[Unit]
Description=Gunicorn daemon for OnCristo
After=network.target

[Service]
User=oncristo
Group=www-data
WorkingDirectory=/home/oncristo/oncristo.local
Environment="PATH=/home/oncristo/oncristo.local/venv/bin"
Environment="DJANGO_ENV=production"
ExecStart=/home/oncristo/oncristo.local/venv/bin/gunicorn \
    --workers 3 \
    --bind 127.0.0.1:8000 \
    --timeout 120 \
    pro_igreja.wsgi:application

[Install]
WantedBy=multi-user.target
```

### 7.2 Iniciar serviço:

```bash
sudo systemctl daemon-reload
sudo systemctl enable gunicorn_oncristo
sudo systemctl start gunicorn_oncristo
sudo systemctl status gunicorn_oncristo
```

---

## 🌐 Passo 8: Configurar Nginx

### 8.1 Criar configuração:

```bash
sudo nano /etc/nginx/sites-available/oncristo
```

Conteúdo:

```nginx
server {
    listen 80;
    server_name oncristo.com.br www.oncristo.com.br;

    # Redirecionar para HTTPS (após configurar SSL)
    # return 301 https://$server_name$request_uri;

    # Por enquanto, servir HTTP
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /static/ {
        alias /home/oncristo/oncristo.local/staticfiles/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    location /media/ {
        alias /home/oncristo/oncristo.local/media/;
        expires 7d;
        add_header Cache-Control "public";
    }

    client_max_body_size 10M;
}
```

### 8.2 Ativar site:

```bash
sudo ln -s /etc/nginx/sites-available/oncristo /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

---

## 🔒 Passo 9: Configurar SSL (Let's Encrypt)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d oncristo.com.br -d www.oncristo.com.br
```

---

## ✅ Passo 10: Verificar Deploy

1. Acesse: https://oncristo.com.br
2. Verifique logs:
   ```bash
   sudo journalctl -u gunicorn_oncristo -f
   sudo tail -f /var/log/nginx/error.log
   ```

---

## 🔄 Comandos Úteis

### Reiniciar serviços:

```bash
sudo systemctl restart gunicorn_oncristo
sudo systemctl restart nginx
```

### Ver logs:

```bash
sudo journalctl -u gunicorn_oncristo -n 50
sudo tail -f /var/log/nginx/access.log
```

### Atualizar código:

```bash
cd /home/oncristo/oncristo.local
source venv/bin/activate
git pull  # ou fazer upload dos arquivos
python manage.py migrate
python manage.py collectstatic --noinput
sudo systemctl restart gunicorn_oncristo
```

---

## ⚠️ Troubleshooting

### Erro de conexão com banco:
- Verificar firewall do Digital Ocean
- Verificar credenciais no `.env_production`
- Testar conexão manual com `mysql`

### Erro 502 Bad Gateway:
- Verificar se Gunicorn está rodando: `sudo systemctl status gunicorn_oncristo`
- Verificar logs: `sudo journalctl -u gunicorn_oncristo -n 50`

### Arquivos estáticos não aparecem:
- Verificar permissões: `sudo chown -R oncristo:www-data /home/oncristo/oncristo.local/staticfiles`
- Verificar `STATIC_ROOT` no `settings.py`

---

## 📝 Notas Importantes

1. **Backup**: Configure backups regulares do banco de dados no painel Digital Ocean
2. **Monitoramento**: Configure alertas de uptime no Digital Ocean
3. **Segurança**: Mantenha o sistema atualizado: `apt update && apt upgrade`
4. **Logs**: Monitore logs regularmente para detectar problemas

